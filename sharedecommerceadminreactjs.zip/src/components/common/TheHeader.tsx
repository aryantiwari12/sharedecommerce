import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useContext } from "react";
import message_img from '../../assets/images/header/messages.jpg'
import { GlobalContext } from '../../context/Provider';
const TheHeader = (props: any) => {

    const { logOutNow } = useContext(GlobalContext);

    const [hideShow, setHideShow] = useState(true)
    const toggleHandler = (pass: boolean) => {
        setHideShow(false)
        props.changeDiv(pass)
    }
    const toggleHandler2 = (passed: Boolean) => {
        setHideShow(true)
        props.changeDiv(passed)
    }
    return (

        <div className="container-fluid">
            <div className="row border-bottom">
                <nav className="navbar d-flex justify-content-between align-items-center p-3" role="navigation" style={{ marginBottom: "0" }}>
                    {/* left side  */}
                    <div className="navbar-header">
                        {hideShow ? <button className="btn btn-theme shadow-none rounded-1" onClick={() => toggleHandler(false)}><i className="fa fa-bars"></i></button>
                            : <button className="btn btn-theme shadow-none rounded-1" onClick={() => toggleHandler2(true)}><i className="fa fa-bars"></i></button>}
                        {/* serach  */}
                        {/* <form role="search" className="navbar-form-custom">
                            <div className="form-group">
                                <input type="text" placeholder="Search for something..." className="form-control shadow-none bg-transparent border-0" name="top-search" id="top-search" />
                            </div>
                        </form> */}
                    </div>

                    {/* right side  */}
                    <ul className="nav gap-3 main-nav align-items-center">
                        {/* welcome text  */}
                        <li>
                            <p>Welcome to HenceForth Ecommerce Admin Panel</p>
                        </li>
                        {/* messages  */}
                        <li>
                            {/* <div className="dropdown">
                                <Link to="" className="btn btn-secondary dropdown-button position-relative bg-transparent border-0" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="fa fa-envelope"></i>  <span className="custom-badge badge rounded-1 text-bg-warning text-white">16</span>
                                </Link>
                                <ul className="dropdown-menu dropdown-menu-end py-0 border-0">
                                    messages-1 
                                    <li className='px-3 py-2'>
                                        <Link to="" className="dropdown-item p-2">
                                            <div className="dropdown-messages-box d-flex gap-2">
                                                <img alt="image" className="rounded-circle" src={message_img} />
                                                <div className="media-body notification-text d-flex gap-2 align-items-start flex-wrap flex-lg-nowrap">
                                                    <div>
                                                        <p><strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>.</p>
                                                        <p><small className="text-muted">3 days ago at 7:58 pm - 10.06.2014</small></p>
                                                    </div>
                                                    <p><small className="pull-right">46h ago</small></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="divider mx-2"></li>
                                    messages-2 
                                    <li className='px-3 py-2'>
                                        <Link to="" className="dropdown-item p-2">
                                            <div className="dropdown-messages-box d-flex gap-2">
                                                <img alt="image" className="rounded-circle" src={message_img} />
                                                <div className="media-body notification-text d-flex gap-2 align-items-start flex-wrap flex-lg-nowrap">
                                                    <div>
                                                        <p><strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>.</p>
                                                        <p><small className="text-muted">3 days ago at 7:58 pm &#8211; 10.06.2014</small></p>
                                                    </div>
                                                    <p><small className="pull-right">46h ago</small></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                </ul>
                            </div> */}
                        </li>
                        {/* Notifications  */}
                        <li>
                            <div className="dropdown">
                                <Link to="" className="btn btn-secondary dropdown-button position-relative bg-transparent border-0" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="fa fa-bell"></i>  <span className="custom-badge badge rounded-1 text-bg-success text-white">16</span>
                                </Link>
                                <ul className="dropdown-menu dropdown-menu-end py-0 border-0">
                                    {/* Notifications-1  */}
                                    <li className='px-3 py-2'>
                                        <Link to="" className="dropdown-item p-2">
                                            <div className="media-body notification-text d-flex justify-content-between align-items-start">
                                                <p><i className="fa fa-envelope fa-fw"></i> You have 16 messages</p>
                                                <p className="pull-right text-muted small">4 minutes ago</p>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="divider mx-2 my-0"></li>
                                    {/* Notifications-2  */}
                                    <li className='px-3 py-2'>
                                        <Link to="" className="dropdown-item p-2">
                                            <div className="media-body notification-text d-flex gap-2 align-items-start">
                                                <p><i className="fa fa-envelope fa-fw"></i> You have 16 messages</p>
                                                <p className="pull-right text-muted small">4 minutes ago</p>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="divider mx-2 my-0"></li>
                                    {/* Notifications-3  */}
                                    <li className='px-3 py-2'>
                                        <Link to="" className="dropdown-item p-2">
                                            <div className="media-body notification-text d-flex gap-2 align-items-start">
                                                <p><i className="fa fa-envelope fa-fw"></i> You have 16 messages</p>
                                                <p className="pull-right text-muted small">4 minutes ago</p>
                                            </div>
                                        </Link>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        {/* Logout button  */}
                        <li>
                            <button type="button" className="btn shadow-none logout-btn border-0 fw-fw-semibold" onClick={() => logOutNow()} >
                                <i className="fa fa-sign-out"></i> Log out
                            </button>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    )
}

export default TheHeader;