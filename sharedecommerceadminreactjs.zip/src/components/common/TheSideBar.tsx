import { Link, useLocation } from 'react-router-dom';
import henceforthApi from '../../utils/henceforthApi';
import henceofrthEnums from '../../utils/henceofrthEnums';
import { useContext, useEffect, useState } from 'react';
import { GlobalContext } from '../../context/Provider';
// import {STAFF_MEMBER,DASHBOARD,USERS,CONTACT,CONTENT,HOME_MANAGEMENT,DB_BACKUP,FAQ,SELLER,PRODUCTS,ORDER,COUPONS,CATEGORY,BRAND,NOTIFICATION} from '../../context/actionTypes'
// import {  } from "../../../constants/actionTypes";
// import {Roles} from "../../utils/henceofrthEnums"
interface stryleCategory {
    _id: string
    name: string
}
const TheSideBar = (props: any) => {
    const { authState, authDispatch, logOutNow } = useContext(GlobalContext);
    const roles = (Array.isArray(authState.roles) ? authState.roles : [])
    const location = useLocation()
    henceforthApi.setToken(authState.access_token);
    const [category, setCategory] = useState<Array<stryleCategory>>([])

    const styleFor = async () => {
        const apiRes = await henceforthApi.HomeManagemnt.styleforlist()
        console.log(apiRes);
        setCategory(apiRes?.data?.data)
    }
    useEffect(() => {
        styleFor()
    }, [])
    return (
        <>
            <div className={props.handled ? "sidebar" : "sidebar mobile-screen"}>
                {/* sidebar Header  */}
                <div className="sidebar-header">
                    <div className='desktop-screen'>
                        {/* user detail  */}
                        <div className="user-detail-box">
                            <img src={authState.image ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${authState.image}` : ""} className="rounded-circle mb-1" alt="img" />
                        </div>
                        <div className="dropdown">
                            <button className="btn shadow-none border-0 dropdown-toggle p-0 text-muted" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                {authState.name ? `${authState.name}` : "Not "}
                            </button>
                            <ul className="dropdown-menu py-0 overflow-hidden">
                                <li className='px-2 pt-2'><Link className="dropdown-item" to="/profile">Profile</Link></li>
                                {(roles.includes(henceofrthEnums.Roles.STAFF_MEMBER)||authState.super_admin) ?
                                <li className='px-2 pt-2'><Link className="dropdown-item" to="/staffs/1">Staff</Link></li>
                                :""}
                                <li className='px-2 pt-2'><Link className="dropdown-item" to="/change-password">Change Password</Link></li>

                                {/* <li className='px-2 py-2'><Link className="dropdown-item" to="">Settings</Link></li> */}
                                <li className='divider'></li>
                                <li className='px-2 py-2'><Link className="dropdown-item" to="" onClick={() => logOutNow()}>Logout</Link></li>
                            </ul>
                        </div>
                    </div>
                </div>
                {/* navigation bar  */}
                <div className='navigation-bar'>
                    <div className="accordion" id="Navigation-bar">
                        {/* Dashboard */}
                        {(roles.includes(henceofrthEnums.Roles.DASHBOARD)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname === '/' ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-th-large me-3 fs-5'></i> {props.handled && <span>Dashboard</span>}
                                </Link>
                            </h6>
                        </div>: ""}
                        {/* Staff  */}
                        {/* <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/staff') ? 'link-active' : ''}`}>
                                <h6 className="accordion-header">
                                    <Link to="/staffs/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                        <i className='fa fa-user-circle-o me-3 fs-5'></i> {props.handled &&<span>Staff</span>}
                                    </Link>
                                </h6>
                            </div> */}
                        {/* User  */}
                        {(roles.includes(henceofrthEnums.Roles.USERS)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/user') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/users/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-users me-3 fs-5'></i> {props.handled && <span>User</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Seller  */}
                        {(roles.includes(henceofrthEnums.Roles.SELLER)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/seller') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/sellers/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-vcard me-3 fs-5'></i> {props.handled && <span>Seller</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Products  */}
                        {(roles.includes(henceofrthEnums.Roles.PRODUCTS)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/product') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/products/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-laptop me-3 fs-5'></i> {props.handled && <span>Product</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Order  */}
                        {(roles.includes(henceofrthEnums.Roles.ORDER)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/order') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/orders/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-shopping-cart me-3 fs-5'></i> {props.handled && <span>Orders</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Coupons  */}
                        {/* {(roles.includes(henceofrthEnums.Roles.COUPONS)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/coupon') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/coupon/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-gift me-3 fs-5'></i> {props.handled && <span>Coupons</span>}
                                </Link>
                            </h6>
                        </div>:""} */}
                        {/* Coupons  */}
                        {(roles.includes(henceofrthEnums.Roles.COUPONS)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/coupon') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header" id="LinkThree4">
                                <button className="accordion-button shadow-none d-flex align-items-center collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarThree1" aria-expanded="false" aria-controls="sidebarThree">
                                    <i className='fa fa-gift me-3 fs-5'></i> {props.handled && <span>Coupon</span>}
                                </button>
                            </h6>
                            <div id="sidebarThree1" className="accordion-collapse collapse" aria-labelledby="LinkThree" data-bs-parent="#Navigation-bar">
                                <div className="accordion-body pt-0">
                                    <ul className='list-unstyled ps-4 sidebar-sublink'>
                                        {/* Banner-1  */}
                                        <li><Link to="/coupon/1">Coupons</Link></li>

                                        {/* Deal of the day  */}
                                        <li><Link to="/coupon/promotional">Home Promotional Coupon</Link></li>

                                        
                                    </ul>
                                </div>
                            </div>
                        </div>:""}
                          {/* Home Page Management  */}
                        {(roles.includes(henceofrthEnums.Roles.HOME_MANAGEMENT)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/management') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header" id="LinkThree2">
                                <button className="accordion-button shadow-none d-flex align-items-center collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarThree" aria-expanded="false" aria-controls="sidebarThree">
                                    <i className='fa fa-list-ul me-3 fs-5'></i> {props.handled && <span>Home Managment</span>}
                                </button>
                            </h6>
                            <div id="sidebarThree" className="accordion-collapse collapse" aria-labelledby="LinkThree" data-bs-parent="#Navigation-bar">
                                <div className="accordion-body pt-0">
                                    <ul className='list-unstyled ps-4 sidebar-sublink'>
                                        {/* Banner-1  */}
                                        <li><Link to="/management/banner/top/1">Banner</Link></li>

                                        {/* Deal of the day  */}
                                        <li><Link to="/management/deals/1">Deals of the day</Link></li>

                                        {/* Top Deals  */}
                                        <li><Link to="/management/top-deal/1">Top Deals</Link></li>

                                        {/* Fashion Deals  */}
                                        <li><Link to="/management/fashion-deal/1">Fashion Deals</Link></li>

                                        {/* Styles  */}
                                        <li>
                                            <div className="accordion" id="Navigation-Inner">
                                                <div className={`accordion-item rounded-0 ${location.pathname.startsWith('unknown') ? 'link-active' : ''}`}>
                                                    <h6 className="accordion-header" id="styleLinks">
                                                        <button className="accordion-button shadow-none d-flex align-items-center collapsed ps-0" type="button" data-bs-toggle="collapse" data-bs-target="#InnerOne" aria-expanded="false" aria-controls="InnerOne">
                                                            <i className='fa fa-user-circle me-3 fs-5'></i><span>Styles</span>
                                                        </button>
                                                    </h6>
                                                    <div id="InnerOne" className="accordion-collapse collapse" aria-labelledby="styleLinks" data-bs-parent="#Navigation-Inner">
                                                        <div className="accordion-body pt-0">
                                                            <ul className='list-unstyled sidebar-sublink ps-3'>
                                                                {category?.map(item => <li><Link to={`/home-management/style-for/${item?.name.toLowerCase()}/${item?._id}/1`}>Style for {item?.name.toLowerCase()} </Link></li>)}
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* Featured Categories  */}
                                        <li><Link to="/management/featured-categories/1">Featured Categories of Week</Link></li>
                                        {/* Shop with us  */}
                                        <li><Link to="/management/shop-with-us/1">Shop with us</Link></li>
                                        {/* Best of electronics */}
                                        <li><Link to="/management/best-of-ecommerce/1">Best of E-commerce</Link></li>
                                    </ul>
                                </div>
                            </div>
                        </div>:""}
                        {/* Catgeory  */}
                        {(roles.includes(henceofrthEnums.Roles.CATEGORY)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/category') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header" id="subCategoriesThree">
                                <button className="accordion-button shadow-none d-flex align-items-center collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#subCateThree" aria-expanded="false" aria-controls="subCateThree">
                                    <i className='fa fa-cutlery me-3 fs-5'></i> {props.handled && <span>Category</span>}
                                </button>
                            </h6>
                            <div id="subCateThree" className="accordion-collapse collapse" aria-labelledby="subCategoriesThree" data-bs-parent="#Navigation-bar">
                                <div className="accordion-body pt-0">
                                    <ul className='list-unstyled ps-4 sidebar-sublink'>
                                        <li><Link to="/category/level-1/1">Category (level 1)</Link></li>
                                        <li><Link to="/category/level-2/1">Sub-Category (level 2)</Link></li>
                                        <li><Link to="/category/level-3/1">Sub-Sub-Category (level 3)</Link></li>
                                    </ul>
                                </div>
                            </div>
                        </div>:""}
                        {/* Brands  */}
                        {(roles.includes(henceofrthEnums.Roles.BRAND)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/brands') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/brands/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-folder me-3 fs-5'></i> {props.handled && <span>Brands</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Content  */}
                        {(roles.includes(henceofrthEnums.Roles.CONTENT)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/content') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/content" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-folder me-3 fs-5'></i> {props.handled && <span>Content</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Rating & Review */}
                        {(roles.includes(henceofrthEnums.Roles.REATING)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/rating/1') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/rating/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-star me-3 fs-5'></i> {props.handled && <span>Rating & Review</span>}
                                </Link>
                            </h6>
                        </div>:""}
                           {/* Earning*/}
                           {(roles.includes(henceofrthEnums.Roles.REATING)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/earning/1') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/earning/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa fa-dollar me-3 fs-5'></i> {props.handled && <span>Earning</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        
                        {/* FAQ  */}
                        {(roles.includes(henceofrthEnums.Roles.FAQ)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/faq') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/faq" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-question-circle me-3 fs-5'></i> {props.handled && <span>FAQ</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Contact  */}
                        {(roles.includes(henceofrthEnums.Roles.CONTACT)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/contact') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/contact-us/1" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-address-book me-3 fs-5'></i> {props.handled && <span>Contact</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Notification  */}
                        {(roles.includes(henceofrthEnums.Roles.NOTIFICATION)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/notification') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/notifications" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-bell me-3 fs-5'></i> {props.handled && <span>Notification</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* DB Backup  */}
                        {(roles.includes(henceofrthEnums.Roles.DB_BACKUP)||authState.super_admin) ?
                        <div className={`accordion-item rounded-0 ${location.pathname.startsWith('/backup') ? 'link-active' : ''}`}>
                            <h6 className="accordion-header">
                                <Link to="/database" className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link">
                                    <i className='fa fa-database me-3 fs-5'></i> {props.handled && <span>DB Backup</span>}
                                </Link>
                            </h6>
                        </div>:""}
                        {/* Logout  */}
                        <div className={`accordion-item rounded-0`}>
                            <h6 className="accordion-header">
                                <button className="accordion-button shadow-none d-flex align-items-center collapsed text-decoration-none single-link" type="button" onClick={() => logOutNow()}>
                                    <i className='fa fa-sign-out me-3 fs-5'></i> {props.handled && <span>Logout</span>}
                                </button>
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            {/* } */}
        </>
    )
}

export default TheSideBar;