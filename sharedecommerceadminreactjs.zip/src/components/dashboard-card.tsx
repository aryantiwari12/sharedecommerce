import { Link } from "react-router-dom";


const DashboardCard = (props: any) => {
    return (
        <Link to={props.link ? props.link : '#'}>
            <div className="dashboard-card">
                {/* card title  */}
                <div className="dashboard-card-title d-flex justify-content-between align-items-start">
                    <h5>{props.title}</h5>
                    <span className='px-2'><small>Monthly</small></span>
                </div>
                {/* count and Description */}
                <div className="dashboard-card-content d-flex justify-content-between align-items-center">
                    <div className="dashboard-count-description">
                        <h2 className="m-0">{props.count}</h2>
                        <small>{props.description}</small>
                    </div>
                    {/* Iocn  */}
                    <div className='dashboard-card-icon'>
                        <i className={`fa ${props.icon}`}></i>
                    </div>
                </div>
            </div>
        </Link>
    )
}
export default DashboardCard;