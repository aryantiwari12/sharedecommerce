 const Spinner = () => {

    return <div className={`spinner-border spinner-grow-sm d-flex mx-auto`}  role="status">
        <span className="visually-hidden"></span>
    </div>
}
export default Spinner;