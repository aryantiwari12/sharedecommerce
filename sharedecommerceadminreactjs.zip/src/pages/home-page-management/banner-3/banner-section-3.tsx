import '../../../assets/styles/pages.scss'
import profile_image from '../../../assets/images/pages/profile-image.jpg'
import { Link } from 'react-router-dom'
const BannerSection3 = () => {
    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <div className='d-flex justify-content-between align-items-center'>
                                <div>
                                    {/* title  */}
                                    <h2 className='fw-semibold'>Banner List</h2>
                                    {/* breadcrum  */}
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb m-0">
                                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                            <li className="breadcrumb-item active fw-bold">Banner list</li>
                                        </ol>
                                    </nav>
                                </div>
                                {/*  button  */}
                                <div className='buttons-box'>
                                    <div className='d-inline-flex gap-3 '>
                                        <Link to="/add-banner" className="btn btn-white btn-sm" type="button"> <i className='fa fa-plus me-1'></i>Add</Link>
                                        <button className="btn btn-white btn-sm border-danger bg-danger text-white" type="button"> <i className="fa fa-ban me-1"></i>Enable/Disable</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-listing'>
                    <div className="container-fluid">
                        <div className="row">
                            {/* 1  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 2  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 3  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 4  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 5  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 6  */}
                            <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={profile_image} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to="/view-banner" className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to="/edit-banner" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>

        </>
    )
}
export default BannerSection3;