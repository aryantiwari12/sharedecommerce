import '../../../assets/styles/auth.scss'
import '../../../assets/styles/pages.scss'
import profile_img from '../../../assets/images/pages/profile-image.jpg'
import { Link, useMatch } from 'react-router-dom'
import { useContext, useEffect, useState } from 'react'
import henceforthApi from '../../../utils/henceforthApi'
import { GlobalContext, handleError } from '../../../context/Provider'
import { toast } from 'react-toastify'
import Spinner from '../../../components/BootstrapCompo'

const EditBanner = () => {

    const { authState, authDispatch } = useContext(GlobalContext);
    const match: any = useMatch("/management/banner1/:type/:_id/edit")
    const [loading, setloading] = useState(false)
    const [category, setCategory] = useState([])
    const [categoryId, setCategoryId] = useState("")
    const [subCategoryId, setSubcategoryId] = useState("")
    const [showimg, setshowimg] = useState(true)
    const [file, setfile] = useState(null as any)

    const [brand, setbrand] = useState([])
    const [brandID, setbrandID] = useState("")

    const [subCategory, setSubCategory] = useState([])

    const [subSubCategory, setSubSubCategory] = useState([])
    const [subSubCategoryId, setSubSubcategoryId] = useState("")

    const [position, setposition] = useState("")

    const [state, setstate] = useState({

        image: "",
        title: "",
        sub_title: "",
        category_id: {
            name: ""
        },
        sub_subcategory_id: {
            name: ""
        },
        subcategory_id: {
            name: ""
        },
        brand_id: {
            name: ""
        }
    })
    const fileUpload = async () => {
        try {
            const apiRes = await henceforthApi.Common.do_spaces_file_upload("file", file)
            const data = apiRes.data
            console.log(data)
            return data.file_name

        } catch{}
    }
    const handlesubmit = async (e: any) => {
        e.preventDefault()
        setloading(true)
        try {

            const image = await fileUpload()

            const data = {
                _id: match.params._id,
                title: state.title,
                sub_title: state.sub_title,
                image: image,
                category_id: categoryId,
                subcategory_id: subCategoryId,
                sub_subcategory_id: subSubCategoryId,
                brand_id: brandID,
                position: String(match?.params.type).toUpperCase(),
                language: "ENGLISH"
            }
            let apires = await henceforthApi.HomeManagemnt.editbanner(data)
            toast.success(apires.message)
            window.history.back()
        } catch (error) {
            handleError(error)
        } finally {
            setloading(false)
        }
    }
    const Back = () => {
        window.history.back()
    }
    const handlechnage = (e: any) => {
        let name = e.target.name;
        let value = e.target.value;
        setstate({
            ...state,
            [name]: value
        })
    }
    const Removeimage = () => {
        const element = document.getElementById('rem')
        setstate({image:""}as any)
        setshowimg(false)
    }
    const initialise = async () => {
        try {
            let apires = await henceforthApi.HomeManagemnt.viewbanner(match?.params._id)
            setstate(apires?.message)
        } catch (error) {

        } finally {

        }
    }
    const initialiseBrand = async () => {
        try {
            let apires = await henceforthApi.HomeManagemnt.Brands()
            setbrand(apires?.data.data)
        } catch {
            console.log("error")
        }
    }
    const initialiseCategoryLevel3 = async () => {
        try {
            const apiRes = await henceforthApi.Category.filterSubSubCategory(subSubCategoryId)
            setSubSubCategory(apiRes?.data.data)
        } catch (error) {
            handleError(error)
        }
    }
    const initialiseCategoryLevel2 = async () => {
        try {
            const apiRes = await henceforthApi.Category.filterSubCategory(categoryId)
            setSubCategory(apiRes?.data.data)
        } catch (error) {
            handleError(error)
        }
    }
    const initialiseCategoryLevel1 = async () => {
        try {
            const apiRes = await henceforthApi.Category.listCategory()
            setCategory(apiRes?.data.data)
        } catch (error) {
            handleError(error)
        }
    }

    useEffect(() => {
        initialise()
    }, [])
    useEffect(() => {
        if (categoryId) {

            initialiseCategoryLevel2()
        }
    }, [categoryId])
    useEffect(() => {
        if (subCategoryId) {
            initialiseCategoryLevel3()
        }
    }, [subCategoryId])
    useEffect(() => {
        if (subCategoryId) {
            initialiseBrand()
        }
    }, [subCategoryId])
    useEffect(() => {
        initialiseCategoryLevel1()
    }, [])

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Edit Banner</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Edit Banner</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Edit Banner</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={handlesubmit}>
                                            {/* Upload image */}
                                            <div className='upload-fields-box mb-3 position-relative'>
                                                <div className='banner-edit-image mb-2'>
                                                    <div className='banner-edit-upload'>
                                                        <input type="file" onChange={(e: any) => setfile(e.target.files[0])} />
                                                    </div>
                                                    <img src={file ? URL.createObjectURL(file as any) : state.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state.image}` : "Not Avaiable"} alt="img" id="rem" />
                                                </div>
                                                <p><small><strong>Note:-</strong> Please upload only .jpg and .png format only.</small></p>
                                                {/* Remove Button  */}
                                                <div className='remove-image-button'>
                                                    {showimg === true ? <button type='button' className='btn w-100 text-white bg-danger border-danger rounded-0' onClick={Removeimage}><i className='fa fa-trash me-2'></i>Remove Image</button> : ""}

                                                </div>
                                            </div>
                                            {/* Title*/}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold' >Title</label>
                                                <input type="text" className="form-control rounded-0" value={state.title} onChange={handlechnage} name="title" />
                                            </div>
                                            {/* Sub Title */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Sub Title</label>
                                                <input type="text" className="form-control rounded-0" value={state.sub_title} onChange={handlechnage} name="sub_title" />
                                            </div>
                                            {/* postion Banner */}
                                            <div className='form-select-box mb-3'>
                                                <label className='mb-1 fw-bold'>position</label>
                                                <select className="form-select" aria-label="Default select example" value={position} onChange={(e: any) => setposition(e.target.value)}>
                                                    <option value="TOP">TOP</option>
                                                    <option value="MIDDLE">MIDDLE</option>
                                                    <option value="BOTTOM">BOTTOM</option>
                                                </select>
                                            </div>
                                            {/* Category level-1 */}
                                            <div className='form-select-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-1</label>
                                                <select className="form-select" aria-label="Default select example" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} >
                                                    <option value="">{state.category_id?.name}</option>
                                                    {category.map((res: any, index: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}
                                                </select>
                                            </div>
                                            {/* Category level-2 */}
                                            <div className='form-select-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-2</label>
                                                <select className="form-select" aria-label="Default select example" value={subCategoryId} onChange={(e) => setSubcategoryId(e.target.value)} >
                                                    <option value="">{state.sub_subcategory_id?.name}</option>
                                                    {subCategory.map((res: any, index: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}
                                                </select>
                                            </div>
                                            {/* Category level-3 */}
                                            <div className='form-select-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-3</label>
                                                <select className="form-select" aria-label="Default select example" value={subSubCategoryId} onChange={(e) => setSubSubcategoryId(e.target.value)}>
                                                    <option value="">{state.subcategory_id?.name}</option>
                                                    {subSubCategory?.map((res: any) =>
                                                        <option value={res._id}>{res.name}</option>
                                                    )}
                                                </select>
                                            </div>
                                            {/* Brand */}
                                            <div className='form-select-box mb-3'>
                                                <label className='mb-1 fw-bold'>Brand</label>
                                                <select className="form-select" aria-label="Default select example" value={brandID} onChange={(e) => setbrandID(e.target.value)}>
                                                    <option value="">{state.brand_id?.name}</option>
                                                    {brand.map((res: any) =>
                                                        <option value={res._id}>{res.name}</option>
                                                    )}
                                                </select>
                                            </div>
                                            {/* Submit Button  */}
                                            <div className='signin-button-box'>
                                                <ul className='list-unstyled d-flex gap-2'>
                                                    <li className='w-100'><button type='button' className='btn btn-white w-100 bg-danger text-white' onClick={Back}><i className='fa fa-ban me-2'></i>Cancel</button></li>
                                                    <li className='w-100'> <button type='submit' className='btn btn-theme w-100' disabled={loading}><i className='fa fa-save me-2'></i>{loading ? <Spinner /> : "Save"}</button></li>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </>
    )
}
export default EditBanner;