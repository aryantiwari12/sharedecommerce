import '../../../assets/styles/pages.scss'
import { Link, useMatch, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import henceforthApi from '../../../utils/henceforthApi'
import { handleError } from '../../../context/Provider'
import EnableDisable from '../../../components/common/enableDisable'

const BannerSection = () => {
    const navigate = useNavigate()
    const match = useMatch("management/banner/:type/:page")
    let limit=10;
    const [state, setState] = useState({
        data: [],
        total_count: 0,

    })
    const[loading,setLoading]=useState(false)
    const [checkenable, setcheckenable] = useState([])
    let checkdata = checkenable[0]
    const initialise = async () => {
        try {
            setLoading(true)
            const apiRes = await henceforthApi.HomeManagemnt.bannerlisting(String(match?.params.type).toUpperCase(), Number(match?.params.page) - 1, limit)
            setState(apiRes.data)
            setcheckenable({
                ...apiRes.data.data.map((items: any) => {
                    if (items.is_enable === true) {
                        return true
                    }
                })
            })
            setLoading(false)

        } catch (error) {
            handleError(error)
        }
    }
    const enableDisable = async () => {

        try {
            const data = {
                position: match?.params.type?.toUpperCase(),
                is_enable: checkdata === true ? false : true
            }

            // console.log(state.is_enable)
            let apiRes = await henceforthApi.enableDisable.enableDisableBanner(data)
            initialise()
        } catch (error) {
            handleError(error)
        } finally {

        }
    }
    const onChangeType = (value: string) => {
        navigate(`/management/banner/${value}/1`)
    }
    const onChangePage = (value: number) => {
        navigate(`/management/banner/${match?.params.type}/${value}`)
    }

    useEffect(() => {
        initialise()
    }, [match?.params.type, match?.params.page])

 console.log(state)
    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <div className='d-flex justify-content-between align-items-center'>
                                <div>
                                    {/* title  */}
                                    <h2 className='fw-semibold'>Banner List</h2>
                                    {/* breadcrum  */}
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb m-0">
                                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                            <li className="breadcrumb-item active fw-bold">Banner list</li>
                                        </ol>
                                    </nav>
                                </div>
                                {/*  button  */}
                                <div className='buttons-box'>
                                    <div className='d-inline-flex gap-3 '>
                                        <Link to={`/management/banner/${match?.params.type}/add`} className="btn btn-white btn-sm" type="button"> <i className='fa fa-plus me-1'></i>Add</Link>
                                        <select className="btn btn-white btn-sm" value={match?.params.type} onChange={(e) => onChangeType(e.target.value)}>
                                            <option value="top">Top</option>
                                            <option value="middle">Middle</option>
                                            <option value="bottom">Bottom</option>
                                        </select>
                                        {/* <button className="btn btn-white btn-sm border-danger bg-danger text-white" type="button" onClick={enableDisable}>
                                            <span> <i className="fa fa-ban me-1"></i>{checkdata ? "Disable" : "Enable"}</span>
                                        </button> */}
                                           <EnableDisable checkdata={checkdata} isEnableDisable={enableDisable} loading={loading}/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-listing'>
                    <div className="container-fluid">
                        <div className="row">
                            {/* 1  */}
                            {Array.isArray(state?.data) && (state?.data.length) ? state?.data.map((res: any, index: any) => <div className="col-md-4">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* image  */}
                                        <div className="profile-image">
                                            <img src={`${henceforthApi.API_FILE_ROOT_MEDIUM}${res.image}`} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Product Detail  */}
                                        <div className="profile-image my-4">
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>{res.title}</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span>{res.sub_title}</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> {res.category_id?.name}</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> {res.subcategory_id?.name}</p>
                                            {res.sub_subcategory_id?.name &&
                                                <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span>{res.sub_subcategory_id?.name}</p>}
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>{res.brand_id?.name}</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button d-flex gap-2">
                                            <Link to={`/management/view-banner/${match?.params.type}/${res._id}`} className='btn btn-white bg-danger text-white border-danger w-100'> <i className='fa fa-eye me-1'></i>View</Link>
                                            <Link to={`/management/banner1/${match?.params.type}/${res._id}/edit`} className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            ):""}
                        </div>

                    </div>
                </section>
            </div>

        </>
    )
}
export default BannerSection;