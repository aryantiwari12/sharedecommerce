import '../../../assets/styles/auth.scss'
import '../../../assets/styles/pages.scss'
import profile_img from '../../../assets/images/pages/profile-image.jpg'
import { Link } from 'react-router-dom'
const ViewFashionBanner = () => {
    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">View Banner</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">View Banner</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title d-flex justify-content-between align-items-center">
                                        <h5>View Banner</h5>
                                        <div className='edit-button'>
                                            <Link to="/edit-fashion-banner" type='button' className='btn btn-white w-100'><i className='fa fa-edit me-2'></i>Edit</Link>
                                        </div>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        {/* image */}
                                        <div className='upload-fields-box mb-3'>
                                            <div className='banner-view-image mb-2'>
                                                <img src={profile_img} alt="img" className='w-100' />
                                            </div>
                                        </div>
                                        {/* Banner Detail  */}
                                        <div className="profile-image my-4">
                                            <h5 className='mb-3'>Banner Section</h5>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span> LIFESTYLE</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Sub Title:</span> Up To 50% OFF</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> Cloths</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-2:</span> Pants</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-3:</span> Jeans</p>
                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Brand:</span>Nike</p>
                                        </div>
                                        {/* Button  */}
                                        <div className='signin-button-box'>
                                            <ul className='list-unstyled d-flex gap-2 flex-column'>
                                                <li className='w-100'><Link to="/fashion-banner" type='button' className='btn btn-white w-100'><i className='fa fa-arrow-left me-2'></i>Back</Link></li>
                                                <li className='w-100'> <button type='button' className='btn btn-white w-100 border-black bg-black text-white'><i className='fa fa-ban me-2'></i>Disable/Enable</button></li>
                                                <li className='w-100'> <button type='button' className='btn btn-white w-100 bg-danger text-white'><i className='fa fa-trash me-2'></i>Remove</button></li>
                                                <li className='w-100'> <button type='button' className='btn btn-theme w-100'><i className='fa fa-save me-2'></i>Save</button></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div >

        </>
    )
}
export default ViewFashionBanner;