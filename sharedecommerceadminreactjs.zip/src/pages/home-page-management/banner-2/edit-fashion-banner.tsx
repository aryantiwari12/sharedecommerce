import '../../../assets/styles/auth.scss'
import '../../../assets/styles/pages.scss'
import profile_img from '../../../assets/images/pages/profile-image.jpg'
import { Link } from 'react-router-dom'
const EditFashionBanner = () => {
    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Edit Banner</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Edit Banner</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Edit Banner</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form action="">
                                            {/* Upload image */}
                                            <div className='upload-fields-box mb-3 position-relative'>
                                                <div className='banner-edit-image mb-2'>
                                                    <div className='banner-edit-upload'>
                                                        <input type="file" />
                                                    </div>
                                                    <img src={profile_img} alt="img" />
                                                </div>
                                                <p><small><strong>Note:-</strong> Please upload only .jpg and .png format only.</small></p>
                                                {/* Remove Button  */}
                                                <div className='remove-image-button'>
                                                    <button type='button' className='btn w-100 text-white bg-danger border-danger'><i className='fa fa-trash me-2'></i>Remove Image</button>
                                                </div>
                                            </div>
                                            {/* Title*/}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Title</label>
                                                <input type="text" className="form-control rounded-0" value='LIFESTYLE' />
                                            </div>
                                            {/* Sub Title */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Sub Title</label>
                                                <input type="text" className="form-control rounded-0" value='Up To 50% OFF' />
                                            </div>
                                            {/* Category level-1 */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-1</label>
                                                <input type="text" className="form-control rounded-0" value='Cloths' />
                                            </div>
                                            {/* Category level-2 */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-2</label>
                                                <input type="text" className="form-control rounded-0" value='Pants' />
                                            </div>
                                            {/* Category level-3 */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Category level-3</label>
                                                <input type="text" className="form-control rounded-0" value='Jeans' />
                                            </div>
                                            {/* Brand */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Brand</label>
                                                <input type="text" className="form-control rounded-0" value='Nike' />
                                            </div>
                                            {/* Submit Button  */}
                                            <div className='signin-button-box'>
                                                <ul className='list-unstyled d-flex gap-2'>
                                                    <li className='w-100'><Link to="/fashion-banner" type='button' className='btn btn-white w-100 bg-danger text-white'><i className='fa fa-ban me-2'></i>Cancel</Link></li>
                                                    <li className='w-100'> <button type='submit' className='btn btn-theme w-100'><i className='fa fa-save me-2'></i>Save</button></li>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </>
    )
}
export default EditFashionBanner;