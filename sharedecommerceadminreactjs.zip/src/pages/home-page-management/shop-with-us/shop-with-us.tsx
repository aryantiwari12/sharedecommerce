import '../../../assets/styles/pages.scss'
import profile_image from '../../../assets/images/pages/profile-image.jpg'
import { Link, Navigate, useMatch, useNavigate } from 'react-router-dom'
import { useContext, useEffect, useState } from 'react'
import henceforthApi from '../../../utils/henceforthApi'
import { GlobalContext, handleError } from '../../../context/Provider'
import FashionDeal from '../fashion-deal/fashion-deal'
import Spinner from '../../../components/BootstrapCompo'
import { toast } from 'react-toastify'
import PaginationLayout from '../../../components/PaginationLayout'
import { numberWithCommas } from '../../../utils/validations'
import EnableDisable from '../../../components/common/enableDisable'
import Swal from 'sweetalert2'



const ShopWithUs = () => {

    const { loading, setLoading } = useContext(GlobalContext)
    const match: any = useMatch("/management/shop-with-us/:page")
    let limit = 10
    const navigate = useNavigate()
    const [state, setstate] = useState<any>({
        data: []
    })
    const [checkEnable,setCheckEnable]=useState([])
    let checkdata=checkEnable[0]
    const [totalCount, setTotalCount] = useState(0)
    const intialise = async () => {
        setLoading(true)
        try {
            let apires = await henceforthApi.Shopwith.shoplist(
                limit,
                Number(match?.params.page) - 1
            )
            setCheckEnable({
                ...apires.data.data.map((res: any) => {
                    if (res.is_enable === true) {
                        return true
                    }
                })
            })
            setstate(apires.data)
            setTotalCount(apires.data.total_count)
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }
    const isEnableDisable=async()=>{
        const data={
            is_enable:checkdata===true ? false :true 
        }
        try {
             let apiRes=await henceforthApi.Shopwith.isEnableDisable(data)
            //  toast.success(apiRes.message)
             intialise()
        } catch (error) {
            
        }
    }
    const onChangeDelete = async (_id: any, index: any) => {
        let data = state.data
        data[index].loading = true
        setstate({
            ...state,
            data
        })
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
        }).then(async (result: any) => {
            if (result.isConfirmed) {
                try {
                    let apiRes = await henceforthApi.Shopwith.deleteShop(_id)
                    toast.success(apiRes.message)
                    intialise()
                } catch (error) {
                    handleError(error)
                } finally {
                    data[index].loading = false
                }
            }
            data[index].loading = false
            intialise()
        })
    }
    const onChangePagination = (newval: any) => {
        navigate({ pathname: `/management/shop-with-us/${newval}` })
    }

    useEffect(() => {
        intialise()
    }, [match.params.page])

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <div className='d-flex justify-content-between align-items-center'>
                                <div>
                                    <h2 className='fw-semibold'>Shop With Us</h2>
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb m-0">
                                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                            <li className="breadcrumb-item active fw-bold">Shop With Us</li>
                                        </ol>
                                    </nav>
                                </div>
                                <div className='enable-diable-button'>
                                    <Link to="/management/shop-with-us/add" className="btn btn-white btn-sm" type="button"> <i className='fa fa-plus me-1'></i>Add</Link>
                                      <EnableDisable checkdata={checkdata} isEnableDisable={isEnableDisable} loading={loading}/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            {loading ? <div className='vh-100 d-flex justify-content-center py-5'><Spinner /></div> :
                <div className='page-spacing'>
                    <section className='product-listing'>
                        <div className="container-fluid">
                            <div className="row">
                                {/* 1  */}
                                {(Array.isArray(state.data)) && (state.data.length) ? state.data.map((res: any, index: any) => {
                                    return (
                                        <>
                                            <div className="col-md-3">
                                                <div className="common-card">
                                                    <div className="common-card-content">
                                                        {/* image  */}
                                                        <div className="profile-image">
                                                            <img src={res.image ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res.image}` : "Not avaiable"} alt="img" className='img-fluid' />
                                                        </div>
                                                        {/* Product Detail  */}
                                                        <div className="profile-image my-4">
                                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Title:</span>{res.title ? res.title : "Not Aaviable"}</p>
                                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Price:</span>&#x24; {res.price ? numberWithCommas(res.price) : "Not Aaviable"}</p>
                                                            <p className="d-flex align-items-center mb-1"><span className='fw-bold me-2'>Category level-1:</span> {res.category_id?.name ? res.category_id?.name : "Not Avaiable"}</p>
                                                        </div>
                                                        {/* button  */}
                                                        <div className="profile-button d-flex gap-2">
                                                            <button className='btn btn-white bg-danger text-white border-danger w-100' onClick={() => onChangeDelete(res._id, index)} disabled={res.loading} ><i className='fa fa-trash me-2'></i>{res.loading ? <Spinner /> : "Delete"}</button>
                                                            <Link to={`/management/edit-shop/${res._id}`} className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i> Edit</Link>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </>
                                    )
                                }) : "Not found data"}

                            </div>

                            {/* Pagination  */}
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="common-card">
                                        <div className="common-card-content">

                                            {/* pagination  */}
                                            <PaginationLayout
                                                count={totalCount}
                                                data={state?.data}
                                                page={Number(match?.params.page)}
                                                limit={Number(limit)}
                                                onPageChange={(val: any) => onChangePagination(val)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>}

        </>
    )
}
export default ShopWithUs;