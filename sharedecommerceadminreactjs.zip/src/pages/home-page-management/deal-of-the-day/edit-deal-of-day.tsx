import '../../../assets/styles/auth.scss'
import '../../../assets/styles/pages.scss'
import profile_img from '../../../assets/images/pages/profile-image.jpg'
import { Link, useMatch } from 'react-router-dom'
import { GlobalContext, handleError } from '../../../context/Provider'
import { useContext, useEffect, useState } from 'react'
import henceforthApi from '../../../utils/henceforthApi'
import { stat } from 'fs'
import Spinner from '../../../components/BootstrapCompo'
import { toast } from 'react-toastify'
import { setEngine } from 'crypto'




const EditDealOfDay = () => {

    const match = useMatch("/management/deals/:_id/edit")
    const { authState, authDispatch, brand, category,onChangeBack,
        categoryId, setCategoryId, subCategory, subCategoryId, setSubCategoryId,
        subSubCategory, subSubCategoryId, setSubSubcategoryId, loading, setLoading, brandID, setbrandID } = useContext(GlobalContext);
    const [file, setfile] = useState(null as any)
    const [state, setstate] = useState({


        image: "",
        title: "",
        price: "",
        discount: "",
        brand_id: {
            _id: "",
            name: ""
        },
        category_id: {
            _id: "",
            name: ""
        },
        subcategory_id: {
            id: "",
            name: ""
        },
        sub_subcategory_id: {
            _id: "",
            name: ""
        }


    })
 

    const initialise = async () => {
        try {
            let apires = await henceforthApi.Dealsofday.viewdeals(match?.params._id)
            setstate(apires.message)
        } catch (error) {
            handleError(error)
        } finally {

        }
    }
    const fileUpload = async () => {
        try {
            const apiRes = await henceforthApi.Common.do_spaces_file_upload("file", file[0])
            const data = apiRes.data
            console.log(data)
            return data.file_name

        } catch (error) {
            handleError(error)
        }
    }
    const onHandleChange = async (e: any) => {
        e.preventDefault()
        // if (!file && !state.title && !state.price && !state.category_id && !state.subcategory_id 
        //     && !state.sub_subcategory_id && !state.brand_id ) {
        //     seterror({
        //         ...error,
        //         image: "please upload",
        //         title: "Please fill title",
        //         price: "Please enter price",
        //         category_id: "Please choose category_id",
        //         subcategory_id: "please choose subCategory_id",
        //         sub_subcategory_id: "please choose sub_subcategory_id",
        //         brand_id:"please choose brand_id"
        //     })
        //     return
        // }

        // if (!file) return seterror({ ...error, image: "please upload image" })
        // if (!state.title) return seterror({ ...error, title: "Please fill title" })
        // if (!state.price) return seterror({ ...error, price: "please enter price" })
        // if (!state.category_id) return seterror({ ...error, category_id: "please choose categoryName" })
        // if (!state.subcategory_id) return seterror({ ...error, subcategory_id: "please choose subCategoryName" })
        // if (!state.sub_subcategory_id) return seterror({ ...error, sub_subcategory_id: "please choose subSubCategoryName" })
        // if (!state.brand_id) return seterror({ ...error, brand_id: "please choose brandName" })
        

        try {
            setLoading(true)
            const image = await fileUpload()
            const data = {
                _id: match?.params._id,
                image: image,
                title: state.title,
                price: state.price,
                discount: state.discount,
                category_id: categoryId,
                subcategory_id: subCategoryId,
                sub_subcategory_id: subSubCategoryId,
                brand_id: brandID,
                language: "ENGLISH"
            }
            console.log(image)
            let apiRes = await henceforthApi.Dealsofday.editDeals(data)
            toast.success(apiRes.message)
            window.history.back()
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }
    const handlechnage = (e: any) => {
        let name = e.target.name;
        let value = e.target.value;

        // if (name === "image") {
        //     seterror({
        //         ...error,
        //         image: ""
        //     })
        // } if (name === "title") {
        //     seterror({
        //         ...error,
        //         title: ""
        //     })
        // } if (name === "price") {
        //     seterror({
        //         ...error,
        //         price: ""
        //     })
        // } if (name === "category_id") {
        //     seterror({
        //         ...error,
        //         category_id: ""
        //     })
        // } if (name === "subcategory_id") {
        //     seterror({
        //         ...error,
        //         subcategory_id: ""
        //     })
        // } if (name === "sub_subcategory_id") {
        //     seterror({
        //         ...error,
        //         sub_subcategory_id: ""
        //     })
        // } if(name === "brand_id"){
        //     seterror({
        //         ...error,
        //         brand_id:""
        //     })
        // }

        setstate({
            ...state,
            [name]: value
        })
    }




    useEffect(() => {
        initialise()
    }, [])

    console.log(state)

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Edit Deal Of Day</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Edit Deal Of Day</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-3">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Edit Deal of Day</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={onHandleChange}>
                                            {/* Upload image */}
                                            <div className='upload-fields-box mb-3 is-invalid'>
                                                <div className='banner-edit-image full-home-image img mb-2'>
                                                    <div className='banner-edit-upload'>
                                                        <input type="file" onChange={(e: any) =>  setfile(e.target.files) } />
                                                    </div>
                                                    <img src={file ? URL.createObjectURL(file[0]) : state.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state.image}` : "Not Avaiable"} alt="img"
                                                        className={`form-control  rounded-0`}
                                                    />
                                                </div>
                                                <p><small><strong>Note:-</strong> Please upload only .jpg and .png format only.</small></p>

                                            </div>
                                            {/* error msg  */}
                                            {/* <div className={`${error.image ? "invalid-feedback" : ""}`}>
                                                {error.image}
                                            </div> */}
                                            {/* Title*/}
                                            <div className='form-fields-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Title</label>
                                                <input type="text" className="form-control  rounded-0" value={state.title} onChange={handlechnage} name="title" />
                                            </div>
                                            {/* error msg  */}
                                            {/* <div className={`${error.title ? "invalid-feedback" : ""}`}>
                                                {error.title}
                                            </div> */}
                                            {/* Price */}
                                            <div className='form-fields-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Price(&#8377;)</label>
                                                <input type="text" className="form-control  rounded-0" value={state.price} onChange={handlechnage} name="price" />
                                            </div>
                                            {/* error msg  */}
                                            {/* <div className={`${error.price ? "invalid-feedback" : ""}`}>
                                                {error.price}
                                            </div> */}
                                            {/* Category level-1 */}
                                            <div className='form-select-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Category level-1</label>
                                                <select className="form-select rounded-0" aria-label="Default select example" value={categoryId} onChange={(e) =>  setCategoryId(e.target.value) }>
                                                    <option value="">{state.category_id?.name}</option>
                                                    {category.map((res: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}
                                                </select>
                                                {/* error msg  */}
                                                {/* <div className={`${error.category_id ? "invalid-feedback" : ""}`}>
                                                    {error.category_id}
                                                </div> */}
                                            </div>

                                            {/* Category level-2 */}
                                            <div className='form-select-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Category level-2</label>
                                                <select className="form-select " aria-label="Default select example" value={subCategoryId} onChange={(e) => setSubCategoryId(e.target.value) }>
                                                    <option value="">{state.subcategory_id?.name}</option>
                                                    {subCategory.map((res: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}

                                                </select>
                                                {/* error msg  */}
                                                {/* <div className={`${error.subcategory_id ? "invalid-feedback" : ""}`}>
                                                    {error.subcategory_id}
                                                </div> */}
                                            </div>
                                            {/* Category level-3 */}
                                            <div className='form-select-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Category level-3</label>
                                                <select className="form-select" aria-label="Default select example" value={subSubCategoryId} onChange={(e) =>  setSubSubcategoryId(e.target.value) } >
                                                    <option value="">{state.sub_subcategory_id?.name ? state.sub_subcategory_id?.name : "Not Aaviable "}</option>
                                                    {subSubCategory.map((res: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}

                                                </select>
                                                {/* error msg  */}
                                                {/* <div className={`${error.sub_subcategory_id ? "invalid-feedback" : ""}`}>
                                                    {error.sub_subcategory_id}
                                                </div> */}
                                            </div>
                                            {/* Brand */}
                                            <div className='form-select-box mb-3 is-invalid'>
                                                <label className='mb-1 fw-bold'>Brand</label>
                                                <select className="form-select" aria-label="Default select example" value={brandID} onChange={(e) => setbrandID(e.target.value)} >
                                                    <option value="">{state.brand_id?.name}</option>
                                                    {brand.map((res: any) => {
                                                        return (
                                                            <>
                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        )
                                                    })}

                                                </select>
                                                {/* error msg  */}
                                                {/* <div className={`${error.brand_id ? "invalid-feedback" : ""}`}>
                                                    {error.brand_id}
                                                </div> */}
                                            </div>

                                            {/* Discount */}
                                            <div className='form-fields-box mb-3'>
                                                <label className='mb-1 fw-bold'>Discount</label>
                                                <input type="text" className="form-control rounded-0" value={`${state.discount}`} onChange={handlechnage} name="discount" />
                                            </div>
                                            {/* Submit Button  */}
                                            <div className='signin-button-box'>
                                                <ul className='list-unstyled d-flex gap-2'>
                                                    <li className='w-100'><button type='button' className='btn btn-white w-100 bg-danger text-white' onClick={onChangeBack} ><i className='fa fa-ban me-2'></i>Cancel</button></li>
                                                    <li className='w-100'> <button type='submit' className='btn btn-theme w-100'><i className='fa fa-save me-2'></i>{loading ? <Spinner /> : "Save"}</button></li>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </>
    )
}
export default EditDealOfDay;