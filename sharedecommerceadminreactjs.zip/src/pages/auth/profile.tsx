import profile_img from '../../assets/images/pages/profile-image.jpg';
import '../../assets/styles/pages.scss'
import { Link } from 'react-router-dom';
import { useContext, useEffect, useState } from 'react';
import { GlobalContext } from '../../context/Provider';
import loginSuccess from '../../context/actions/auth/loginSuccess';
import henceforthApi from '../../utils/henceforthApi';

const Profile = () => {

    const { authState, authDispatch } = useContext(GlobalContext);
    henceforthApi.setToken(authState.access_token);

    const [commission,setCommission]=useState({
       data:{
        fee_percent:Number()
       }
    }as any)

    const Commission=async()=>{
        try {
            let apiRes=await henceforthApi.commission.getCommission()
            setCommission(apiRes?.data)
        } catch (error) {
            
        }
    }
   useEffect(()=>{
    Commission()
   },[])

console.log(commission.data.fee_percent);

    return (<>
        {/* breadcrum  */}
        <section className="breadcrum-box">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">
                        {/* title  */}
                        <h2>Profile</h2>
                        {/* breadcrum  */}
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                <li className="breadcrumb-item active fw-bold">Profile</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        {/* page  */}
        <div className='page-spacing'>
            <section className='change-password'>
                <div className="container-fluid">
                {/* col-md-7 col-lg-6 col-xl-5 col-xxl-3 */}
                    <div className="row justify-content-center">
                        <div className="col-sm-6  ">
                            {/* Title  */}
                            <div className="common-card">
                                <div className="common-card-title">
                                    <h5>My Profile</h5>
                                </div>
                                {/* Profile  */}
                                <div className="common-card-content">
                                    {/* Profile image  */}
                                    <div className="profile-image">
                                        <img src={authState.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${authState.image}` : ""} alt="img" className='img-fluid' />
                                    </div>
                                    {/* Profile Detail  */}
                                    <div className="profile-image my-4">
                                        <h5 className='mb-3'>{authState.name ? authState.name : ""}</h5>
                                        <p className="d-flex align-items-center mb-1">
                                            <i className='fa fa-envelope me-2 fs-5'></i>
                                            {authState.email ? authState.email : ""}
                                        </p>
                                        <p className="d-flex align-items-center">
                                            <i className='fa fa-phone-square me-2 fs-5'></i>
                                            <span>{authState.phone_number}</span>
                                        </p>
                                    </div>
                                    {/* button  */}
                                    <div className="profile-button">
                                        <Link to="/edit-profile" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i>Edit Profile</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-6 ">
                            {/* Title  */}
                            <div className="common-card">
                                <div className="common-card-title">
                                    <h5>My Commission</h5>
                                </div>
                                {/* Profile  */}
                                <div className="common-card-content">
                                    {/* Profile image  */}
                                    {/* <div className="profile-image">
                                        <img src={authState.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${authState.image}` : ""} alt="img" className='img-fluid' />
                                    </div> */}
                                    {/* Profile Detail  */}
                                    <div className="profile-image my-4">
                                        <label>Fee Percent:</label>
                                        <span >{commission.data.fee_percent}%</span>
                                        {/* <p className="d-flex align-items-center mb-1">
                                            <i className='fa fa-envelope me-2 fs-5'></i>
                                            {authState.email ? authState.email : ""}
                                        </p> */}
                                        {/* <p className="d-flex align-items-center">
                                            <i className='fa fa-phone-square me-2 fs-5'></i>
                                            <span>{authState.phone_number}</span>
                                        </p> */}
                                    </div>
                                    {/* button  */}
                                    <div className="profile-button">
                                        <Link to="/edit-commission" className='btn btn-theme w-100'><i className='fa fa-edit me-2'></i>Edit Commission</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </>
    )
}

export default Profile;