import defaultIcon from '../../assets/images/default.jpg';
import '../../assets/styles/pages.scss'
import { Link, useMatch } from 'react-router-dom'
import { useEffect, useState } from 'react';
import henceforthApi from '../../utils/henceforthApi';
import DownloadFileModal from '../../components/common/download-file-modal';
const ViewStaff = () => {
    const match = useMatch("staff/:_id")
    const [state, setState] = useState({
        data: {
            _id: "",
            name: "",
            image: "",
            email: "",
            country_code: "",
            phone_number: "",
            roles: [],
            super_admin: false,
            is_blocked: false,
            is_deleted: false,
            created_at: ""
        }
    })


    const initialise = async () => {
        try {
            const apiRes = await henceforthApi.Staff.get(match?.params?._id as string)
            setState(apiRes)
        } catch (error) {

        }
    }

    useEffect(() => {
        initialise()
    }, [])
    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 className='fw-semibold'>View Staff</h2>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">View Staff</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='change-password'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-3">
                                {/* Title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>View Staff</h5>
                                    </div>
                                    {/* Profile  */}
                                    <div className="common-card-content">
                                        {/* Profile image  */}
                                        <div className="profile-image">
                                            <img src={state?.data?.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state?.data?.image}` : defaultIcon} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Profile Detail  */}
                                        <div className="profile-image my-4">
                                            <h5 className='mb-3'>{state?.data?.name}</h5>
                                            <p className="d-flex align-items-center mb-1"><i className='fa fa-user me-2 fs-5'></i>{state.data.roles.map((item: string, index: number) => `${item}${state.data.roles.length - 1 === index ? '' : ','} `)}</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button">
                                            <ul className='list-unstyled d-flex gap-2'>
                                                <li className='w-100'><button type='button' className='btn btn-white w-100 bg-danger text-white'><i className='fa fa-trash me-1'></i> Delete</button></li>
                                                <li className='w-100'> <Link to="edit" className='btn btn-theme w-100'><i className='fa fa-edit me-1'></i> Edit</Link></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <DownloadFileModal />
        </>
    )
}
export default ViewStaff;