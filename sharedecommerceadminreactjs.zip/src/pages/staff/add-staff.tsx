import { Link } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import henceforthApi from '../../utils/henceforthApi'
import { useContext, useRef, useState } from 'react'
import { GlobalContext, handleError } from '../../context/Provider'
import { toast } from 'react-toastify'
import defaultIcon from '../../assets/images/default.jpg'
import Profile_placeholder from '../../assets/images/profile_placeholder.png'
import Spinner from '../../components/BootstrapCompo'


const AddStaff = () => {
    const { authState, staffMembers } = useContext(GlobalContext);
    henceforthApi.setToken(authState.access_token);
    let ref1=useRef() as any
    const [loading, setLoading] = useState(false)
    const [selectedFile, setSelectedFile] = useState(null as any)
    const [name, setName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [roles, setRoles] = useState([] as Array<string>)

    const fileupload = async (file: any) => {
        try {
            const apiRes = await henceforthApi.Common.do_spaces_file_upload("file", file)
            const file_name = apiRes.data.file_name
            return file_name
        } catch {
            return ""
        }
    }

    const handleInput = (value: string, b: boolean, index2: number) => {
        let row = roles
        if (b === false) {
            row = roles.filter((item: any) => {
                return item != value
            })
        }
        b === true ? setRoles([...roles, value]) : setRoles([...row])
    }

    const handlesubmit = async (e: any) => {
        e.preventDefault()
        const items = {
            name,
            email,
            roles,
            password,
            language: "ENGLISH"
        } as any
        setLoading(true)
        if (selectedFile) {
            const image = await fileupload(selectedFile)
            if (image) {
                items.image = image
            }
        }
        try {
            let apires = await henceforthApi.Staff.add(items)
            toast.success(apires.message)
            window.history.back()
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Add Staff</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Add Staff</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-8 col-lg-7 col-xl-6 col-xxl-4">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Add Staff</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={handlesubmit}>
                                            {/* Upload image */}
                                            <div className='upload-fields-box mb-3'>
                                                <div className='profile-edit-image mb-2'>
                                                    <div className='profile-edit-upload'>
                                                        <input type="file" onChange={(e: any) => setSelectedFile(e.target.files[0])} accept="image/*" />
                                                    </div>
                                                    <img src={selectedFile ? URL.createObjectURL(selectedFile) : Profile_placeholder} alt="img" className='rounded-circle' />
                                                </div>
                                                <p className='text-center'><small><strong>Note:-</strong> Please upload only .jpg and .png format only.</small></p>
                                            </div>
                                            {/* Name */}
                                            <div className='form-fields-box mb-3'>
                                                <input type="text" className="form-control rounded-0" placeholder='Name' value={name} onChange={(e) => setName(e.target.value)} name="name" required />
                                            </div>
                                            <div className='form-fields-box mb-3'>
                                                <input type="text" className="form-control rounded-0" placeholder='Email' value={email} onChange={(e) => setEmail(e.target.value)} name="email" required />
                                            </div>
                                            <div className='form-fields-box mb-3'>
                                                <input type="password" className="form-control rounded-0" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} name="email" required />
                                            </div>
                                            {/* Role */}
                                            <div className='form-radio-box mb-3'>
                                                {/* <input type="text" className="form-control rounded-0" placeholder='Role' required multiple /> */}
                                                <div className='d-inline-flex flex-wrap'>
                                                    {staffMembers.map((res: string, index: number) =>
                                                        <div key={res} className="form-check w-50">
                                                            <input className="form-check-input shadow-none"  type="checkbox" value={res} checked={roles.includes(res)} ref={ref1} onChange={(e) => handleInput(res, e.target.checked, index)} id={`roleslist${index}`} />
                                                            <label className="form-check-label" htmlFor={`roleslist${index}`}>
                                                            {res} 
                                                            </label>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            {/* Button  */}
                                            <div className='signin-button-box'>
                                                <ul className='list-unstyled d-flex gap-2'>
                                                    <li className='w-100'><Link to="/staff-listing" type='button' className='btn btn-white w-100 bg-danger text-white'><i className='fa fa-ban me-2'></i>Cancel</Link></li>
                                                    <li className='w-100'> <button type='submit' className='btn btn-theme w-100' disabled={loading}><i className='fa fa-save me-2'></i>{loading ? <Spinner /> : 'Save'}</button></li>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </>
    )
}
export default AddStaff;