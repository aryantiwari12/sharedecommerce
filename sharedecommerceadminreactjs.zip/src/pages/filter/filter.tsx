import moment from "moment"
import { useContext, useEffect, useRef } from "react"
import { useLocation } from "react-router-dom"
import { GlobalContext } from "../../context/Provider"
import henceofrthEnums from "../../utils/henceofrthEnums"
import { capitalise } from "../../utils/validations"
import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
const filter = [
    { min_price: '100', max_price: '500' },
    { min_price: '501', max_price: '1000' },
    { min_price: '1001', max_price: '2000' },
]
export default (props: any) => {
    const location = useLocation()
    const newParam = new URLSearchParams(location.search)
    const { handleSearch, onFilterPriceHandler } = useContext(GlobalContext)

    const [showCalendar, setShowCalendar] = useState(false)
    const calendarDropRef = useRef<any>(null)

    const dateSelect = (e: any) => {
        handleSearch('start_date', e[0] ? String(moment(e[0]).valueOf()) : '')
        handleSearch('end_date', e[1] ? String(moment(e[1]).valueOf()) : '')
        setShowCalendar(false)
    }
    const handleClickOutside = (e: any) => {
        if (calendarDropRef.current && !calendarDropRef?.current.contains(e.target)) {
            setShowCalendar(false)
        }
    }

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);
    console.log(moment(Number(newParam.get('start_date'))).toDate());

    return <div className='common-card mb-4 border-0 card-spacing'>
        <div className="row justify-content-between gy-3">
            {/* serach and filter  */}
            <div className="col-md-10">
                <div className="row">
                    <div className="col-4">
                        <div className='form-fields-box'>
                            <label className='mb-1 form-label fw-semibold'>Search</label>
                            <div className='position-relative'>

                                <input type="search" className="form-control rounded-0 ps-4 " name='search' value={newParam.has("search") ? newParam.get("search") as string : ""} placeholder="Search"
                                    onChange={(e) => {
                                        handleSearch(e.target.name, e.target.value)
                                    }} />
                                <span className='search-icon'><i className='fa fa-search'></i></span>
                            </div>
                        </div>
                    </div>
                    {props.product_id ? <div className="col-3">
                        <div className='form-fields-box'>
                            <label className='mb-1 form-label fw-semibold'>Search ProductID</label>
                            <div className='position-relative'>
                                <input type="search" className="form-control rounded-0 ps-4 " name='product_id' value={newParam.has("product_id") ? newParam.get("product_id") as string : ""} placeholder="Search ProductID"
                                    onChange={(e) => {
                                        handleSearch(e.target.name, e.target.value)
                                    }} />
                                <span className='search-icon'><i className='fa fa-search'></i></span>
                            </div>
                        </div>
                    </div> : ''}
                    {/* Price Range  */}
                    <div className="col-2">
                        <div className='form-select-box'>
                            <label className='mb-1 form-label fw-semibold'>Price Filter</label>
                            <div className="dropdown">
                                <button className="btn btn-white dropdown-toggle shadow-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    {newParam.has("min_price") && newParam.has("max_price") ? `$ ${newParam.get("min_price")} - ${newParam.get("max_price")}` : 'Filter by price'}</button>
                                <ul className="dropdown-menu pb-0">
                                    {/* <li>Filters</li> */}
                                    <li>Price Filter</li>
                                    {Array.isArray(filter) && filter.map((res: any, index: number) => <li key={index} onClick={() => onFilterPriceHandler(res.min_price, res.max_price)}>
                                        <a className="dropdown-item" href='#'>
                                            <div className="form-check d-flex gap-2">
                                                <label className="form-check-label" htmlFor={`flexCheckDefault${index}`}>
                                                    <input className="form-check-input shadow-none" type="radio" name='filterPrice' checked={newParam.has("min_price") && newParam.has("max_price") ? newParam.get("min_price") === res?.min_price && newParam.get("max_price") === res?.max_price : false} id={`flexCheckDefault${index}`} onChange={(e) => console.log(e)} />
                                                    &#36; {res?.min_price} <span>-</span> {res?.max_price}
                                                </label>
                                            </div>
                                        </a>
                                    </li>)}
                                    <li onClick={(e) => onFilterPriceHandler('filterPrice', '')}>
                                        <button className="dropdown-item ps-0 border border-bottom-0 text-center" >
                                            Clear
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    {props.filters ? <div className="col-2">
                        <div className='form-select-box'>
                            <label className='mb-1 form-label fw-semibold'>Filters </label>
                            <div className="dropdown">
                                <button className="btn btn-white dropdown-toggle shadow-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    {newParam.get('stock')?capitalise(newParam.get('stock')):newParam.get('order_status')?`${capitalise(newParam.get('order_status'))} Status`:newParam.get('payment_status')?`${capitalise(newParam.get('payment_status'))} Status`:'All Filters'}
                                    </button>
                                <ul className="dropdown-menu pb-0">
                                    {/* <li>Filters</li> */}
                                    <li onClick={() => { handleSearch('stock', '');handleSearch('payment_status', '');handleSearch('order_status', '')}}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        All Status
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                    {props.stock ? <>     
                                    <li className="ps-3">Stock Status <i className={newParam.has("stock") ? 'fa fa-circle' : ''}></i></li>
                                        {/* <li onClick={() => { handleSearch('stock', '') }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        All Status
                                                    </label>
                                                </div>
                                            </a>
                                        </li> */}
                                        <li onClick={() => { handleSearch('stock', 'OUT_OF_STOCK') }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        Out Of Stock <i className={newParam.get("stock") === 'OUT_OF_STOCK' ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                        <li onClick={() => { handleSearch('stock', 'ALERT_OF_STOCK') }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        Alert Of Stock <i className={newParam.get("stock") === 'ALERT_OF_STOCK' ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li></> : ''}
                                    {props.orderStatus ? <>   
                                    <li className="ps-3">Order Status <i className={newParam.has("order_status") ? 'fa fa-circle' : ''}></i></li>
                                        {/* <li onClick={() => { handleSearch('order_status', '') }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        All Status
                                                    </label>
                                                </div>
                                            </a>
                                        </li> */}
                                        <li onClick={() => { handleSearch('order_status', henceofrthEnums.OrderStatus.CONFIRMED) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        {capitalise(henceofrthEnums.OrderStatus.CONFIRMED)} Status   <i className={newParam.get("order_status") === henceofrthEnums.OrderStatus.CONFIRMED ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                        <li onClick={() => { handleSearch('order_status', henceofrthEnums.OrderStatus.CANCELLED) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        {capitalise(henceofrthEnums.OrderStatus.CANCELLED)} Status <i className={newParam.get("order_status") === henceofrthEnums.OrderStatus.CANCELLED ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                        <li onClick={() => { handleSearch('order_status', henceofrthEnums.OrderStatus.DELIVERED) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        {capitalise(henceofrthEnums.OrderStatus.DELIVERED)} Status <i className={newParam.get("order_status") === henceofrthEnums.OrderStatus.DELIVERED ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                        <li onClick={() => { handleSearch('order_status', henceofrthEnums.OrderStatus.SHIPPED) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        {capitalise(henceofrthEnums.OrderStatus.SHIPPED)} Status <i className={newParam.get("order_status") === henceofrthEnums.OrderStatus.SHIPPED ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li></> : ''}
                                    {props.refund ? <>
                                        <li className="ps-3">Refund Status <i className={newParam.has("payment_status") ? 'fa fa-circle' : ''}></i></li>
                                        {/* <li onClick={() => { handleSearch('payment_status', '') }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        All Status
                                                    </label>
                                                </div>
                                            </a>
                                        </li> */}
                                        <li onClick={() => { handleSearch('payment_status', henceofrthEnums.OrderStatus.REFUNDED) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        {capitalise(henceofrthEnums.OrderStatus.REFUNDED)} Status <i className={newParam.get("payment_status") === henceofrthEnums.OrderStatus.REFUNDED ? 'fa fa-check' : ''}></i>
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                        <li onClick={() => { handleSearch('payment_status', henceofrthEnums.OrderStatus.REFUND_IN_PROGESS) }}>
                                            <a className="dropdown-item" >
                                                <div className="form-check d-flex gap-2">
                                                    <label className="form-check-label">
                                                        <i className={newParam.get("payment_status") === henceofrthEnums.OrderStatus.REFUND_IN_PROGESS ? 'fa fa-check' : ''}></i> {capitalise(henceofrthEnums.OrderStatus.REFUND_IN_PROGESS)} Status
                                                    </label>
                                                </div>
                                            </a>
                                        </li>
                                    </> : ''}
                                </ul>
                            </div>
                        </div>
                    </div> : ''}
                    {/* {props.stock ? <div className="col-2">
                        <div className="form-select-box">
                            <label htmlFor={props.id} className='fw-semibold mb-1'>Stock Status</label>
                            <select className={`form-select shadow-none`} aria-label=".form-select-sm example" name='stock'
                                onChange={(e: any) => { handleSearch(e.target.name, e.target.value) }} value={newParam.get('stock') ?? ''} style={{ color: 'inherit' }} >
                                <option value="">All Status</option>
                                <option value='OUT_OF_STOCK'>Out Of Stock</option>
                                <option value='ALERT_OF_STOCK'>Alert Of Stock</option>
                            </select>
                        </div>
                    </div> : ''} */}
                    {/* {props.orderStatus ? <div className="form-select-box col-3 mt-3">
                        <label htmlFor={props.id} className='fw-semibold mb-1'>Order Status</label>
                        <select className={`form-select shadow-none`} aria-label=".form-select-sm example" name='order_status'
                            onChange={(e: any) => { handleSearch(e.target.name, e.target.value) }} value={newParam.get('order_status') ?? ''} style={{ color: 'inherit' }} >
                            <option value="">All Status</option>
                            <option value={henceofrthEnums.OrderStatus.CONFIRMED}>{capitalise(henceofrthEnums.OrderStatus.CONFIRMED)} Status</option>
                            <option value={henceofrthEnums.Orde[]rStatus.CANCELLED}>{capitalise(henceofrthEnums.OrderStatus.CANCELLED)} Status</option>
                            <option value={henceofrthEnums.OrderStatus.DELIVERED}>{capitalise(henceofrthEnums.OrderStatus.DELIVERED)} Status</option>
                            <option value={henceofrthEnums.OrderStatus.SHIPPED}>{capitalise(henceofrthEnums.OrderStatus.SHIPPED)} Status</option>
                        </select>
                    </div> : ''} */}
                    {/* {props.refund ? <div className={`form-select-box col-3 ${props.refundMarging ? '' : 'mt-3'}`}>
                        <label htmlFor={props.id} className='fw-semibold mb-1'>Refund Status</label>
                        <select className={`form-select shadow-none`} aria-label=".form-select-sm example" name='payment_status'
                            onChange={(e: any) => { handleSearch(e.target.name, e.target.value) }} value={newParam.get('payment_status') ?? ''} style={{ color: 'inherit' }} >
                            <option value="">All Status</option>
                            <option value={henceofrthEnums.OrderStatus.REFUNDED}>{capitalise(henceofrthEnums.OrderStatus.REFUNDED)} Status</option>
                            <option value={henceofrthEnums.OrderStatus.REFUND_IN_PROGESS}>{capitalise(henceofrthEnums.OrderStatus.REFUND_IN_PROGESS)} Status</option>
                        </select>
                    </div> : ''} */}
                    {props.date ? <div className="col-3"> <div className='form-select-box'>
                        <label className='mb-1 form-label fw-semibold'>Start to End Date</label>
                        <div className={`dropdown ${newParam.has('start_date') && newParam.has('end_date') ? 'btn-group' : ''}`} ref={calendarDropRef}>
                            {/* <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="visually-hidden">Toggle Dropdown</span>
                            </button> */}
                            <button className="btn btn-white dropdown-toggle shadow-none" type="button" onClick={() => setShowCalendar(!showCalendar)}>
                                Date Filter</button>
                            {newParam.has('start_date') && newParam.has('end_date') ? <button type="button" className="btn btn-white shadow-none" onClick={() => { handleSearch('start_date', ''); handleSearch('end_date', ''); setShowCalendar(false) }}>
                                x
                            </button> : ''}
                            <ul className={`dropdown-menu py-0  ${showCalendar ? 'show' : ''} `}>
                                <Calendar onChange={(e: any) => dateSelect(e)} maxDate={new Date()} selectRange value={newParam.has('start_date') && newParam.has('end_date') ? [moment(Number(newParam.get('start_date'))).toDate(), moment(Number(newParam.get('end_date'))).toDate()] : new Date()} />
                                {/* <button className="w-100" onClick={() => { handleSearch('start_date', ''); handleSearch('end_date', '') }}>Clear Date</button> */}
                                {/* value={value} onChange={onChange} */}
                            </ul>
                        </div>
                    </div> </div> : ''}
                    {/* {props.date ?
                        <div className='d-flex gap-2 col-3'>
                            <div className='form-fields-box mt-3'>
                                <label className='mb-1 form-label fw-semibold'>Start date:</label>
                                <input type="date" className='form-control rounded-0' name='start_date' value={newParam.has("start_date") ? moment(Number(newParam.get('start_date'))).format("YYYY-MM-DD") : moment().format("MM/DD/YYYY")} placeholder='dd/mm/yy'
                                    onChange={(e) => handleSearch(e.target.name, e.target.valueAsNumber ? `${e.target.valueAsNumber}` : '')}

                                />
                            </div>
                            <div className='form-fields-box mt-3'>
                                <label className='mb-1 form-label fw-semibold'>End date:</label>
                                <input type="date" className='form-control rounded-0' name='end_date' min={newParam.has("start_date") ? moment(Number(newParam.get('start_date'))).add(1, 'days').format("YYYY-MM-DD") : moment().format("MM/DD/YYYY")} value={newParam.has("end_date") ? moment(Number(newParam.get('end_date'))).format("YYYY-MM-DD") : moment().format("MM/DD/YYYY")} placeholder='dd/mm/yy'
                                    onChange={(e) => handleSearch(e.target.name, e.target.valueAsNumber ? `${e.target.valueAsNumber}` : '')}
                                    disabled={!newParam.has("start_date")}
                                />
                            </div>
                        </div>
                        : ''} */}
                </div>
            </div>
            {/* export  */}
            <div className="col-md-2">
                <div className='d-flex gap-3 justify-content-end'>
                    <div className='download-export-box'>
                        <label className='mb-1 form-label fw-semibold'>Export File</label>
                        <div className="export-button">
                            <button className="btn btn-white" type="button" data-bs-toggle="modal" data-bs-target="#fileDownloadModal"> <i className='fa fa-cloud-download me-2'></i>.csv</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
}