import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import defaultImage from '../../assets/images/pages/defaultImage.jpg'
import { Link, useLocation, useMatch, useNavigate } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import { Fragment, useContext, useEffect, useState } from 'react'
// import PaginationLayout from '../../components/common/PaginationLayout'
import { GlobalContext, handleError } from '../../context/Provider'
import henceforthApi from '../../utils/henceforthApi'
// import Spinner from '../../components/common/spinner'
import moment from 'moment'
// import BreadCrumb from '../../components/common/BreadCrumb'
import { numberWithCommas } from '../../utils/validations'
import Spinner from '../../components/BootstrapCompo'
import BreadCrumb from '../../components/common/BreadCrumb'
// import AllFilter from '../../components/common/AllFilter'
// import { orderListType } from '../order/orderInterface'
import profile_placeholder from '../../assets/images/pages/profile_placeholder.png'
import PaginationLayout from '../../components/PaginationLayout'


const EarningPage = () => {
    let Limit = 10
    const location = useLocation()
    const navigate = useNavigate()
    const match = useMatch('/earning/:page')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Ratings & Reviews List', url: ``, active: 'not-allowed' }
    ]
    let limit = 10;
    const newParam = new URLSearchParams(location.search);
    const [state, setstate] = useState({
        data: [] as any,
        product_id: {}

    })
    const { authState, loading, setLoading, authDispatch } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [totalCount, setTotalCount] = useState(0)


    const handleSearch = (name: string, value: any) => {
        if (value) {
            newParam.set(name, value)
        } else {
            if (newParam.has(name)) {
                newParam.delete(name)
            }
        }
        navigate({ pathname: `/earning/1`, search: newParam.toString() })
    }
    const onChangePriceHandler = async (min_price: string, max_price: string) => {
        if (min_price && max_price) {
            newParam.set("min_price", min_price)
            newParam.set("max_price", max_price)
        } else {
            if (newParam.has("min_price")) {
                newParam.delete('min_price')
            }
            if (newParam.has("max_price")) {
                newParam.delete('max_price')
            }
        }
        navigate({ pathname: '/earning/1', search: newParam.toString() })
    }
    const exportData = async (startDate: number, endDate: number) => {
        try {
            const apiRes = await henceforthApi.Order.export(startDate, endDate)
            const data = apiRes?.data?.data
            const rows = [
                [
                    "Order ID",
                    "Customer Name",
                    "Seller Name",
                    "Product ID",
                    "Product Name",
                    "Product Price  "
                ],
            ];
            if (Array.isArray(data)) {
                data.map((res: any, index: any) => {
                    rows.push([
                        res.order_id,
                        res.user_id?.name,
                        res.seller_id?.name,
                        res?.product_id?._id,
                        res.product_id?.name,
                        res.product_id?.price
                    ])
                })
            }
            let csvContent =
                "data:text/csv;charset=utf-8," +
                rows.map((e) => e.join(",")).join("\n");
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `user_${moment().valueOf()}.csv`);
            document.body.appendChild(link);
            link.click();
            let closeModal = document.getElementById("closeModal");
            if (closeModal) {
                closeModal.click();
            }
        } catch (error) {
            handleError(error)
        }
    }
    const initialise = async () => {
        setLoading(true)
        try {
            let apires = await henceforthApi.Order.getOrder(
                Number(match?.params.page) - 1,
                limit,
                newParam.toString(),
            )
            setstate(apires?.data)
            setTotalCount(apires?.data?.total_count)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    const onChangePagination = (newval: any) => {
        navigate({ pathname: `/earning/${newval}`, search: newParam.toString() })
    }
    useEffect(() => {
        initialise()
    }, [newParam.get('search'), newParam.get('product_id'), newParam.get('min_price'), newParam.get('max_price')])

    console.log(state);



    return (
        <>
            {/* breadcrum  */}
            {/* <BreadCrumb pathNameDeclare={breadCrumbPath} /> */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Earning</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Earning</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* Page  */}
            <div className=' page-spacing'>
                <section className='product-listing'>
                    <div className='product-detail-box'>
                        <div className='common-card mb-4 border-0 card-spacing'>
                            <div className="row justify-content-between">
                                {/* serach and filter  */}
                                <div className="col-md-8">
                                    <div className="row">
                                        <div className="col-7">
                                            <div className='form-fields-box'>
                                                <label className='mb-1 form-label fw-semibold'>Search</label>
                                                <div className='position-relative'>
                                                    <input type="search" className="form-control rounded-0 ps-4 " name='search'
                                                        value={newParam.has('search') ? newParam.get('search') as string : ""}
                                                        placeholder="Search order via  Customer, Seller & Product name..."
                                                        onChange={(e) => handleSearch(e.target.name, e.target.value)}

                                                    />
                                                    <span className='search-icon'><i className='fa fa-search'></i></span>
                                                </div>
                                            </div>
                                            {/* <label className='mb-1 form-label fw-semibold'>Search</label> */}
                                            {/* <div className='position-relative '>
                                                <input type="search" className="form-control rounded-0 ps-4 " name='product_id' placeholder="Search by ProductID..."
                                                    onChange={(e) => {
                                                        handleSearch(e.target.name, e.target.value);

                                                    }}
                                                />
                                                <span className='search-icon'><i className='fa fa-search'></i></span>
                                            </div> */}
                                        </div>

                                        <div className="col-2">
                                            <div className='form-select-box'>
                                                <label className='mb-1 form-label fw-semibold'>Price Filter</label>
                                                <div className="dropdown">
                                                    <button className="btn btn-white dropdown-toggle shadow-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        {newParam.get("min_price") && newParam.get("max_price") ? `$ ${newParam.get("min_price")} - ${newParam.get("max_price")}` : 'Filter by price'}</button>
                                                    <ul className="dropdown-menu pb-0">
                                                        <li onClick={() => onChangePriceHandler("100", "500")}>
                                                            <a className="dropdown-item" href='#'>
                                                                <div className="form-check d-flex gap-2">
                                                                    <label className="form-check-label" htmlFor="flexCheckDefault1">
                                                                        <input className="form-check-input shadow-none" type="radio" name='filterPrice' checked={newParam.has("min_price") && newParam.has("max_price") ? newParam.get("min_price") === '100' && newParam.get("max_price") === '500' : false} id="flexCheckDefault1" />
                                                                        &#36; 100 <span>-</span> 500
                                                                    </label>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li onClick={() => onChangePriceHandler("501", "1000")}>
                                                            <a className="dropdown-item" href='#'>
                                                                <div className="form-check d-flex gap-2">
                                                                    <label className="form-check-label" htmlFor="flexCheckDefault2">
                                                                        <input className="form-check-input shadow-none" type="radio" name='filterPrice' checked={newParam.has("min_price") && newParam.has("max_price") ? newParam.get("min_price") === '501' && newParam.get("max_price") === '1000' : false} id="flexCheckDefault2" />
                                                                        &#36; 501 <span>-</span> 1000
                                                                    </label>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li onClick={() => onChangePriceHandler("1001", "2000")}>
                                                            <a className="dropdown-item" href='#'>
                                                                <div className="form-check d-flex gap-2">
                                                                    <label className="form-check-label" htmlFor="flexCheckDefault3">
                                                                        <input className="form-check-input shadow-none" type="radio" name='filterPrice' checked={newParam.has("min_price") && newParam.has("max_price") ? newParam.get("min_price") === '1001' && newParam.get("max_price") === '2000' : false} id="flexCheckDefault3" />
                                                                        &#36; 1001 <span>-</span> 2000
                                                                    </label>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li onClick={(e) => onChangePriceHandler('filterPrice', '')}>
                                                            <button className="dropdown-item ps-0 border border-bottom-0 text-center" >
                                                                Clear
                                                                {/* <div className="form-check me-2 d-flex justify-content-center"> */}
                                                                {/* <input className="form-check-input shadow-none" type="radio" name='filterPrice' value="" id="flexCheckDefault" onChange={(e) => onChangePriceHandler(e.target.name, e.target.value)} /> */}
                                                                {/* <label className=""  >
                                                                        Clear
                                                                    </label> */}
                                                                {/* </div> */}
                                                            </button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* export  */}
                                <div className="col-md-2">
                                    <div className='d-flex gap-3 justify-content-end'>
                                        <div className='download-export-box'>
                                            <label className='mb-1 form-label fw-semibold'>Export File</label>
                                            <div className="export-button">
                                                <button className="btn btn-white" type="button" data-bs-toggle="modal" data-bs-target="#fileDownloadModal"> <i className='fa fa-cloud-download me-2'></i>.csv</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* Category Filter */}
                            {/* <div className="col-md-12 mt-3">
                            <div className='d-flex gap-3'>
                                <div className='form-select-box w-100'>
                                    <label className='mb-1 form-label fw-semibold'>Category Filter</label>
                                    <select className="form-select shadow-none" value={newParam.has("category_id") ? newParam.get("category_id") as string : ""} aria-label="Default select example" name='category_id'
                                        onChange={(e) => handleSearch(e.target.name, e.target.value)}>
                                        <option value="">Select</option>
                                        {Array.isArray(nestedData) && nestedData.length ?
                                            nestedData.map((res: any) =>
                                                <option value={res?._id}>{res?.name ? res?.name : ""}</option>)
                                            : <option value="">No Data Found</option>}
                                    </select>
                                </div>
                                <div className='w-100'>
                                    {newParam.has("category_id") && <>
                                        <div className='form-select-box'>
                                            <label className='mb-1 form-label fw-semibold'>Subcategory Filter</label>
                                            <select className="form-select shadow-none" aria-label="Default select example" name='subcategory_id' value={newParam.has("subcategory_id") ? newParam.get("subcategory_id") as string : ""} onChange={(e) => handleSearch(e.target.name, e.target.value)}>
                                                <option value="">Select</option>
                                                {(nestedData.find((res: any) => res?._id as string == newParam.get("category_id")) as any)?.sub_categories.map((res: any) =>
                                                    <option value={res._id}>{res?.name ? res?.name : ""}</option>
                                                )}
                                            </select>
                                        </div>
                                    </>}
                                </div>
                                <div className='w-100'>
                                    {newParam.has("subcategory_id") && <>
                                        <div className='form-select-box'>
                                            <label className='mb-1 form-label fw-semibold'>Subcategory Filter</label>
                                            <select className="form-select shadow-none" aria-label="Default select example" name='sub_subcategories' value={newParam.has("sub_subcategories") ? newParam.get("sub_subcategories") as string : ""} onChange={(e) => handleSearch(e.target.name, e.target.value)}>
                                                <option value="">Select</option>
                                                {(nestedData.find((res: any) => res?._id as string == newParam.get("category_id")) as any)?.sub_categories.find((res: any) => res?._id as string == newParam.get("subcategory_id"))?.sub_subcategories.map((res: any) =>
                                                    <option value={res._id}>{res?.name ? res?.name : ""}</option>
                                                )}
                                            </select>
                                        </div>
                                    </>}
                                </div>
                            </div>
                        </div> */}
                            {/* djlk */}
                        </div>

                        <div className="common-card">
                            <div className="common-card-title">
                                <h5>Earning</h5>
                            </div>
                            <div className="common-card-content">
                                {/* table */}

                                <div className='data-list-table table-responsive mb-3'>
                                    <table className="table table-striped align-middle">
                                        <thead className=''>
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Customer Detail</th>
                                                <th>Seller Detail</th>
                                                <th>Product ID</th>
                                                <th>Product Detail</th>
                                                <th>Product Price</th>
                                                <th>Earning</th>
                                                <th>Review</th>

                                            </tr>
                                        </thead>
                                        {state.data.map((res: any) => {
                                            return (
                                                <>
                                                    <tbody>

                                                        <tr>
                                                            <td>{res.order_id}</td>
                                                            <td className='product-image-table'>
                                                                <Link to={`/user/${res?.user_id?._id}`}>
                                                                    <Fragment>
                                                                        <img src={res?.user_id?.profile_pic ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res?.user_id?.profile_pic}` : profile_placeholder} alt="img" className='rounded-circle me-2' />
                                                                        <span>{res.user_id?.name ? res.user_id?.name : "Not Avaiable"}</span>
                                                                    </Fragment>
                                                                </Link>
                                                            </td>
                                                            <td className='product-image-table'>
                                                                <Link to={`/seller/${res?.seller_id?._id}`}>
                                                                    <Fragment>
                                                                        <img src={res.seller_id?.image ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res.seller_id?.image}` : profile_placeholder}
                                                                            alt="img" className='rounded-circle me-2' />
                                                                        <span>{res.seller_id?.name ? res.seller_id?.name : "Not Avaiable"}</span>
                                                                    </Fragment>
                                                                </Link>
                                                            </td>
                                                            <td>{res.product_id?.prd_id}</td>
                                                            <td>
                                                                <Link to={`/product/${res?.product_id?._id}`} className="product-image-table d-flex">
                                                                    <Fragment>
                                                                        {Array.isArray(res.product_id?.images) && (res.product_id?.images?.length) ?
                                                                            <img src={henceforthApi.FILES.imageSmall(res.product_id?.images[0])} alt="img" className='rounded-circle me-2' />

                                                                            : ""}
                                                                        <div>
                                                                            <p title={res.product_id?.name}>{res.product_id?.name ? res.product_id?.name : "Not Aviable"}</p>
                                                                            <p>{res.product_id?.name.charAt(2)}</p>
                                                                        </div>
                                                                    </Fragment>
                                                                </Link>
                                                            </td>
                                                            {/* <td><b>&#8377;</b>{res.total_price.toLocaleString()}</td> */}
                                                            <td><b>&#36;{numberWithCommas(res.total_price)}</b></td>
                                                            <td>{res.total_earnings ? res.total_earnings : "Not Avaiable"}</td>
                                                            <td> <div className="btn-group gap-2">
                                                                <Link className="btn btn-white btn-sm" to={`/order/${res._id}`}> <i className="fa fa-eye me-1"></i>View</Link>
                                                            </div></td>

                                                        </tr>




                                                    </tbody>
                                                </>
                                            )
                                        })}

                                    </table>
                                </div>
                                {/* pagination  */}
                                <div className='dashboad-pagination-box'>
                                    <PaginationLayout
                                        count={totalCount}
                                        data={state?.data}
                                        page={Number(match?.params.page)}
                                        limit={Number(limit)}
                                        loading={loading}
                                        onPageChange={(val: any) => onChangePagination(val)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <DownloadFileModal exportData={exportData} />

        </>
    )
}
export default EarningPage;