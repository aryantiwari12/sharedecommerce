import profile_img1 from '../../assets/images/pages/laptop.jpg';
import '../../assets/styles/pages.scss'

import { Link, useMatch } from 'react-router-dom'
import henceforthApi from '../../utils/henceforthApi';
import { useContext, useEffect, useState } from 'react';
import { GlobalContext, handleError } from '../../context/Provider';
import moment from 'moment';
import Spinner from '../../components/BootstrapCompo';
import { numberWithCommas } from '../../utils/validations';
const ViewProductDetail = () => {
    const { loading, setLoading } = useContext(GlobalContext)
    const match = useMatch('/product/:id')
    const [state, setState] = useState<any>({
        _id: "",
        name: "",
        description: "",
        product_type: "",
        added_by: {
            _id: "",
            name: "",
        },
        category_id: {
            _id: "",
            name: "",
        },
        subcategory_id: {
            _id: "",
            name: "",
        },
        sub_subcategory_id: {
            _id: "",
            name: "",
        },
        brand_id: {
            _id: "",
            name: "",
        },
        images: [],
        quantity: "",
        price: "",
        discount_percantage: "",
        discount: "",
        discount_price: "",
        total_reviews: "",
        total_ratings: "",
        productdetails: [],
        product_services: [],
        product_highlights: [],
        faqs_products: [],
        product_variations: [],
        ratings: [],
    })

    const productDetail = async () => {
        setLoading(true)
        try {
            let res = (await henceforthApi.ProductList.getProductDetail(match?.params.id)).data
            setState(res)
        } catch (err) {
            handleError(err)
        } finally {
            setLoading(false)
        }
    }
    useEffect(() => {
        productDetail()
    }, [])
    return (
        <>
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Product Detail</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Product Detail</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            {loading ? <div className='vh-100 d-flex justify-content-center py-5'>
                <Spinner />
            </div> : <div className='page-spacing'>
                <section className='product-detail'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12">
                                {/* Title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Product Detail</h5>
                                    </div>
                                    {/* Profile  */}
                                    <div className="common-card-content">
                                        <div className="row">
                                            <div className="col-md-5">
                                                <div id="carouselExampleIndicators" className="carousel slide" data-bs-ride="true">
                                                    <div className="carousel-indicators">
                                                        {Array.isArray(state.images) ? state.images.map((res: any, index: number) => {
                                                            return (
                                                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={index} className={index === 0 ? "active" : ""} aria-current="true" aria-label={`Slide ${index + 1}`}></button>
                                                            )
                                                        }) : ""}
                                                    </div>
                                                    <div className="carousel-inner product-images">
                                                        {Array.isArray(state.images) ? state.images.map((res: any, index: number) => {
                                                            return (
                                                                <div className={`carousel-item ${index === 0 ? "active" : ""}`} key={index}>
                                                                    <img src={`${henceforthApi.API_FILE_ROOT_MEDIUM}${res}`} className="d-block w-100" alt={res} />
                                                                </div>
                                                            )
                                                        }) : <div className="carousel-item active">
                                                            <img src={profile_img1} className="d-block w-100" alt="img" />
                                                        </div>}
                                                    </div>
                                                    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                                        <span className="visually-hidden">Previous</span>
                                                    </button>
                                                    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                                        <span className="visually-hidden">Next</span>
                                                    </button>
                                                </div>
                                            </div>
                                            {/* Product detail  */}
                                            <div className="col-md-7">
                                                <div className="product-detail-box">
                                                    <h2 className='fw-bolder'>{state?.name ? state?.name : "Not Available"}</h2>
                                                    <div className='d-flex align-items-center gap-1'>
                                                        <h2 className='fw-lighter m-0'>&#36; {state?.price ? numberWithCommas(state.price) : "Not Available"}</h2><small>Exclude Tax</small>
                                                    </div>
                                                    <div className="divider my-3"></div>
                                                    <div className='mb-3'>
                                                        <h4 className='fw-bolder'>Product description</h4>
                                                        <p>{state?.description ? state?.description : "Not Available"}</p>
                                                    </div>
                                                    <ul className='list-unstyled product-detail-list'>
                                                        <li className="d-flex mb-2"><b className='w-25'>Product ID:</b><span className='flex-grow-1 w-75'>{state?._id ? state?._id : "Not Available"}</span></li>

                                                        <li className="d-flex mb-2"><b className='w-25'>Category Level-1:</b><span className='flex-grow-1 w-75'>{state.category_id.name}</span></li>

                                                        <li className="d-flex mb-2"><b className='w-25'>Category Level-2:</b><span className='flex-grow-1 w-75'>{state?.subcategory_id ? state?.subcategory_id?.name : "Not Available"}</span></li>
                                                        {state?.sub_subcategory_id &&
                                                            <li className="d-flex mb-2"><b className='w-25'>Category Level-3:</b><span className='flex-grow-1 w-75'>{state?.sub_subcategory_id?.name}</span></li>}

                                                        <li className="d-flex mb-2"><b className='w-25'>Brand:</b><span className='flex-grow-1 w-75'>{state?.brand_id ? state?.brand_id?.name : "Not Available"}</span></li>

                                                        <li className="d-flex mb-2"><b className='w-25'>Discount:</b><span className='flex-grow-1 w-75'>{state?.discount_percantage ? `${state?.discount_percantage}%` : "Not Available"}</span></li>
                                                    </ul>
                                                </div>
                                                <div className="divider my-3"></div>
                                                {/* highlights  */}
                                                <div className="product-highlights-box">
                                                    <h2 className='fw-bolder'>Highlights</h2>
                                                    <ul className='product-detail-list ps-0'>
                                                        {Array.isArray(state.product_highlights) ? state.product_highlights.map((res: any) =>
                                                            <li key={res._id}>{res.content}</li>
                                                        ) : "Not Available"}
                                                    </ul>
                                                </div>
                                                <div className="divider my-3"></div>
                                                {/* Specifications  */}
                                                <div className="product-highlights-box">
                                                    <h2 className='fw-bolder'>Specifications</h2>
                                                    <ul className='list-unstyled product-detail-list'>
                                                        {Array.isArray(state.productdetails) && state.productdetails.length ? state.productdetails.map((res: any) => {
                                                            return (

                                                                <li className="d-flex mb-2" key={res._id}>
                                                                    <b className='w-25'>{res.key}</b>
                                                                    <span className='flex-grow-1 w-75'>{res.value}
                                                                    </span>
                                                                </li>
                                                            )
                                                        }) : "Not Available"}
                                                        {/* <li className="d-flex mb-2"><b className='w-25'>Sales Package</b><span className='flex-grow-1 w-75'>Laptop, Power Adaptor, User Guide, Warranty Documents</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Model Number</b><span className='flex-grow-1 w-75'>14s-cf3074TU</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Part Number</b><span className='flex-grow-1 w-75'>1V4R6PA#ACJ</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Series</b><span className='flex-grow-1 w-75'>14s</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Color:</b><span className='flex-grow-1 w-75'>Jet Black</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Battery Cell</b><span className='flex-grow-1 w-75'>3 Cell</span></li> */}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            {/* Product Variables  */}
                            <div className="col-md-4 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Product Variable</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <div className='data-list-table table-responsive mb-3'>
                                            <table className="table table-striped align-middle">
                                                <thead className=''>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Title</th>
                                                        <th>Price</th>
                                                        {/* <th>Action</th> */}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {Array.isArray(state.product_variations) && state.product_variations.length ?
                                                        state.product_variations.map((res: any, index: number) => {
                                                            return (
                                                                <tr key={res._id}>
                                                                    <td>{index + 1}</td>
                                                                    <td>{res.title}</td>
                                                                    <td>&#36;{res.price}</td>
                                                                </tr>
                                                            );
                                                        }) : <tr><td colSpan={4} className="text-center">Not Available</td></tr>}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* services  */}
                            <div className="col-md-4 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Services</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <ul className='product-detail-list ps-0'>
                                            {Array.isArray(state.product_services) && state.product_services.length ? state.product_services.map((res: any) => {
                                                return (
                                                    <li key={res._id} className="text-capitalize">{res.content}</li>
                                                )
                                            }) : <li>Not Available</li>}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            {/* Delivery  */}
                            <div className="col-md-4 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Delivery</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <div className='data-list-table table-responsive mb-3'>
                                            <table className="table table-striped align-middle">
                                                <thead className=''>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Address</th>
                                                        <th>Radius</th>
                                                        {/* <th>Action</th> */}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {state?.delivery_locations?.map((res: any, index: number) =>
                                                        <tr>
                                                            <td>{index + 1}</td>
                                                            <td>{res.address}</td>
                                                            <td>{res.radius}{res.units}</td>
                                                            {/* <td>
                                                                <div className="btn-group gap-2">
                                                                    <button className="btn btn-white btn-sm"> <i className="fa fa-eye me-1"></i>View</button>
                                                                </div>
                                                            </td> */}
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Ratings  */}
                        <div className="row">
                            <div className="col-md-6 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Ratings</h5>
                                    </div>
                                    <div className="common-card-content">
                                        {/* 1  */}
                                        {Array.isArray(state.ratings) && state.ratings.length ? state.ratings.map((res: any) => {
                                            let stared = [...Array(res?.ratings)].map((e, i) => <li key={i}><i className="fa fa-star text-warning"></i></li>)
                                            let staredOff = [...Array(5 - res?.ratings)].map((e, i) => <li key={i}><i className="fa fa-star text-muted"></i></li>)
                                            return (
                                                <>
                                                    <div className='rating-box'>
                                                        <div className="rating-username product-image-table d-flex gap-2 mb-2">
                                                            <img src={res?.user_id?.profile_pic !== null && res?.user_id !== null ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${res.user_id.profile_pic}` : profile_img1} className="border rounded-circle" alt="img" />
                                                            <div>
                                                                <p className='fw-bold'>{res?.user_id?.name ? res?.user_id?.name : "Not Available"}</p>
                                                                <ul className='list-unstyled d-flex gap-1 rating-icons m-0'>
                                                                    {stared}{staredOff}
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div>

                                                            <p className='fw-bold'>{res?.title ? res?.title : "Not Avaialable"}</p>
                                                            <p className='my-1'> {res?.description ? res?.description : "Not Avaialable"} </p>
                                                            <p className='fw-bold'>{res?.created_at ? moment.unix(res?.created_at).format('MMMM Do YYYY, h:mm:ss a') : "Not Avaiable"}</p>
                                                        </div>
                                                    </div>
                                                    <div className='divider my-3'></div>
                                                </>
                                            )
                                        }) : <p>Not Available </p>}
                                    </div>
                                </div>
                            </div>
                            {/* Faq  */}
                            <div className="col-md-6 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>FAQ</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <div className='faq-content-box'>
                                            <div className="accordion" id="faqAccordion">
                                                {/* 1 */}
                                                {Array.isArray(state.faqs_products) && state.faqs_products.length ? state.faqs_products.map((res: any, index: any) => {
                                                    return (
                                                        <div className="accordion-item bg-transparent border border-1 mb-3 position-relative" key={index}>
                                                            <h2 className="accordion-header" id="faqOne">
                                                                <button className="accordion-button shadow-none bg-transparent text-black" type="button" data-bs-toggle="collapse" data-bs-target={`#collapseOne${res._id}`} aria-expanded="true" aria-controls="collapseOne">
                                                                    <b className='me-1'>Q.</b> {res.question}
                                                                </button>
                                                            </h2>
                                                            <div id={`collapseOne${res._id}`} className="accordion-collapse collapse " aria-labelledby="faqOne" data-bs-parent="#faqAccordion">
                                                                <div className="accordion-body border-top border-1 bg-transparent" >
                                                                    <p className='d-flex text-black'><b className='me-1 hellos'>A.</b> <span className='hellos text-black' dangerouslySetInnerHTML={{ __html: res.answer }} /> </p>
                                                                </div>
                                                            </div>
                                                            {/* <ul className="edit-icon-accordion d-flex gap-3 align-items-center mb-0 ps-0 list-unstyled">
                                                                <li><button className='btn p-0 bg-transparent border-0' onClick={() => deleteSpecificDetail("faq", res._id)}><i className='fa fa-trash fs-5'></i></button></li>
                                                                <li> <Link to={`/product/${match?.params.id}/faq/edit/${res._id}`}><i className='fa fa-edit fs-5' role="buton"></i></Link></li>
                                                            </ul> */}
                                                        </div>
                                                    )
                                                }) : "Not Available"}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>}
        </>
    )
}
export default ViewProductDetail;