import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import { Link, useLocation, useMatch, useNavigate } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import { Fragment, useContext, useEffect, useState } from 'react'
import henceforthApi from '../../utils/henceforthApi'
import { listApiResponse } from '../../context/interfaces'
import { GlobalContext, handleError } from '../../context/Provider'
import PaginationLayout from '../../components/PaginationLayout'
import Spinner from '../../components/BootstrapCompo'
import moment from 'moment'
import { numberWithCommas } from '../../utils/validations'
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import Filter from '../filter/filter'

const ProductListing = () => {
    const limit = 10
    const match = useMatch("products/:page")
    const location = useLocation()
    const navigate = useNavigate()
    const newParam = new URLSearchParams(location.search);
    const newParam1 = new URLSearchParams(location.search);
    const { authState, loading, setLoading, nestedData } = useContext(GlobalContext)
    const [value, onChange] = useState<any>();
    const [state, setState] = useState<listApiResponse>()
    henceforthApi.setToken(authState.access_token);
    const handleSearch = (name: string, value: any) => {
        if (value) {
            if(name==="product_id"){
                newParam.delete("search")
            }
            if(name==="search"){
                newParam.delete("product_id")
            }
            newParam.set(name, value)
        } 
  
        else {
            if (newParam.has(name)) {
                newParam.delete(name)

            }
          
        }
        navigate({ pathname: `/products/1`, search: newParam.toString() })
    }
    const onChangePriceHandler = async (min_price: string, max_price: string) => {
        if (min_price && max_price) {
            newParam.set("min_price", min_price)
            newParam.set("max_price", max_price)
        } else {
            if (newParam.has("min_price")) {
                newParam.delete('min_price')
            }
            if (newParam.has("max_price")) {
                newParam.delete('max_price')
            }
        }
        navigate({ pathname: '/products/1', search: newParam.toString() })
    }
    const productlisting = async () => {
        setLoading(true)
        try {
            let apires = await henceforthApi.ProductList.getProductList(
                Number(match?.params.page) - 1,
                limit,
                newParam.toString()
            )
            setState(apires)
        } catch (err) {
            handleError(err)
        } finally {
            setLoading(false)
        }
    }

    const exportData = async (startDate: number, endDate: number) => {
        try {
            const apiRes = await henceforthApi.ProductList.export(startDate, endDate)
            const data = apiRes?.data?.data
            const rows = [
                [
                    "Product Id",
                    "Category Level 1",
                    "Category level 2",
                    "Brand",
                    "Product Name",
                    "Product Price  "
                ],
            ];
            if (Array.isArray(data)) {
                data.map((res: any, index: any) => {
                    rows.push([
                        res._id,
                        res.category_id?.name,
                        res.subcategory_id?.name,
                        res?.brand_id?.name,
                        res.name,
                        res.price
                    ])
                })
            }
            console.log(rows);
            // debugger
            let csvContent =
                "data:text/csv;charset=utf-8," +
                rows.map((e) => e.join(",")).join("\n");
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `user_${moment().valueOf()}.csv`);
            document.body.appendChild(link);
            link.click();
            let closeModal = document.getElementById("closeModal");
            if (closeModal) {
                closeModal.click();
            }
            // debugger
        } catch (error) {
            handleError(error)
        }
    }
    const onChangePagination = (newVal: any) => {
        navigate({ pathname: `/products/${newVal}`, search: newParam.toString() });
    }
    useEffect(() => {
        productlisting()
    }, [newParam.get('start_date'), newParam.get('end_date'),
    newParam.get('search'), newParam.get('product_id'), newParam.get('category_id'), newParam.get('subcategory_id'),
    newParam.get('sub_subcategory_id'), newParam.get('min_price'), newParam.get('max_price'), newParam.get('out_of_stock'),
    match?.params.page])
    // useEffect(() => {
    //     nested()
    // }, [])


    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Product List</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Product List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* Page  */}
            <div className=' page-spacing'>
                <section className='product-listing'>
                    <div className='product-detail-box'>
                        {/* <div className='common-card mb-4 border-0 card-spacing'>
                            <div className="row justify-content-between gy-4">
                                serach and filter 
                                <div className="col-md-12 col-lg-12 col-xxl-12">
                                    <div className="row">
                                        <div className="col-4">
                                            <div className='form-fields-box'>
                                                <label className='mb-1 form-label fw-semibold'>Search</label>
                                                <div className='position-relative'>
                                                    <input type="search" className="form-control rounded-0 ps-4 " name='search' value={newParam.has('search') ? newParam.get('search') as string : ""} placeholder="Search by Product..."
                                                        onChange={(e) => {
                                                            handleSearch(e.target.name, e.target.value);
                                                        }}
                                                    />
                                                    <span className='search-icon'><i className='fa fa-search'></i></span>
                                                </div><br />
                                                <div className='position-relative'>
                                                    <input type="search" className="form-control rounded-0 ps-4 " name='product_id'placeholder="Search by ProductID..."
                                                        onChange={(e) => {
                                                            handleSearch(e.target.name, e.target.value);
                                                            
                                                        }}
                                                    />
                                                    <span className='search-icon'><i className='fa fa-search'></i></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-8">
                                            <div className="row justify-content-center">
                                                <div className="col-md-3">
                                                    <div className='form-select-box'>
                                                        <label className='mb-1 form-label fw-semibold'>Price Filter</label>

                                                        <div className="dropdown">
                                                            <button className="btn btn-white dropdown-toggle shadow-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                                {newParam.get("min_price") && newParam.get("max_price") ? `$ ${newParam.get("min_price")} - ${newParam.get("max_price")}` : 'Filter by price'}</button>
                                                            <ul className="dropdown-menu">
                                                                <li>
                                                                    <a className="dropdown-item bg-transparent d-flex justify-content-between" href='#'>
                                                                        <div className="form-check d-flex gap-2">
                                                                            <input className="form-check-input shadow-none" type="radio"
                                                                                defaultChecked={newParam.has(`min_price`) && newParam.has('max_price') ? newParam.get(`min_price`) === "100" &&
                                                                                    newParam.get('max_price') === "500" : false} name="filterprice" value="" id="flexCheckDefault1"
                                                                                onChange={() => onChangePriceHandler('100', '500')}
                                                                            />
                                                                            <label className="form-check-label" htmlFor="flexCheckDefault1">
                                                                                &#36; 100 <span>-</span> 500
                                                                            </label>
                                                                        </div>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a className="dropdown-item bg-transparent d-flex justify-content-between" href='#'>
                                                                        <div className="form-check d-flex gap-2">
                                                                            <input className="form-check-input shadow-none" type="radio" value=""
                                                                                name="filterprice" id="flexCheckDefault2"
                                                                                defaultChecked={newParam.has(`min_price`) && newParam.has(`max_price`) ? newParam.get(`min_price`) === `501` && newParam.get(`max_price`) === "1000" : false}
                                                                                onChange={() => onChangePriceHandler('501', '1000')}
                                                                            />
                                                                            <label className="form-check-label" htmlFor="flexCheckDefault2">
                                                                                &#36; 501 <span>-</span> 1000
                                                                            </label>
                                                                        </div>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a className="dropdown-item bg-transparent d-flex justify-content-between" href='#'>
                                                                        <div className="form-check d-flex gap-2">
                                                                            <input className="form-check-input shadow-none" type="radio" value=""
                                                                                name="filterprice" id="flexCheckDefault3"
                                                                                defaultChecked={newParam.has(`min_price`) && newParam.has(`max_price`) ? newParam.get(`min_price`) === `1001` && newParam.get(`max_price`) === "2000" : false}
                                                                                onChange={() => onChangePriceHandler('1001', '2000')}
                                                                            />
                                                                            <label className="form-check-label" htmlFor="flexCheckDefault3"
                                                                            >
                                                                                &#36; 1001 <span>-</span> 2000
                                                                            </label>
                                                                        </div>
                                                                    </a>
                                                                </li>
                                                                <button className='w-100 border-0' onClick={() => onChangePriceHandler('', '')}>
                                                                    <label className='text-center' role="button"> Clear</label>
                                                                </button>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                filter by date 
                                                <div className="col-md-6">
                                                    <div className='d-flex gap-2'>
                                                        <div className='form-fields-box'>
                                                            <label className='mb-1 form-label fw-semibold'>Start date:</label>
                                                            <input type="date" className='form-control rounded-0' name='start_date' value={newParam.has("start_date") ? moment(Number(newParam.get('start_date'))).format("YYYY-MM-DD") : moment().format("MM/DD/YYYY")} placeholder='dd/mm/yy'
                                                                onChange={(e) => handleSearch(e.target.name, e.target.valueAsNumber)}
                                                            />
                                                        </div>
                                                        <div className='form-fields-box'>
                                                            <label className='mb-1 form-label fw-semibold'>End date:</label>
                                                            <input type="date" className='form-control rounded-0' name='end_date' value={newParam.has("end_date") ? moment(Number(newParam.get('end_date'))).format("YYYY-MM-DD") : moment().format("MM/DD/YYYY")} placeholder='dd/mm/yy'
                                                                onChange={(e) => handleSearch(e.target.name, e.target.valueAsNumber)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <Calendar   value={value} onChange={onChange} selectRange />
                                                export 
                                                <div className="col-md-3">
                                                    <div className='d-flex gap-3 justify-content-end'>
                                                        <div className='download-export-box'>
                                                            <label className='mb-1 form-label fw-semibold'>Export File</label>
                                                            <div className="export-button">
                                                                <button className="btn btn-white" type="button" data-bs-toggle="modal" data-bs-target="#fileDownloadModal"> <i className='fa fa-cloud-download me-2'></i>.csv</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div> */}
                        <Filter date="active"/>

                        <div className="common-card">
                            <div className="common-card-title d-flex justify-content-between">
                                <h5>Product Listing
                                </h5>
                                {/* <div>
                                    <Link to="/category/level-1/add" className="btn btn-white" >
                                        <i className='fa fa-plus me-2'></i> Add Category
                                    </Link>
                                </div> */}
                            </div>
                            <div className="common-card-content ">
                                {/* table */}
                                <div className='data-list-table table-responsive mb-3'>
                                    {loading ? <div className='vh-100 d-flex justify-content-center py-5'>
                                        <Spinner />
                                    </div> : <table className="table table-striped align-middle">
                                        <thead className=''>
                                            <tr>
                                                <th>Product Id</th>
                                                <th>Category Level 1</th>
                                                <th>Category level 2</th>
                                                <th>Brand</th>
                                                <th>Product Image</th>
                                                <th>Product Name</th>
                                                <th>Product Price</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {state?.data.data.map((res: any, index: any) => {
                                                return (
                                                    <>
                                                        <tr>
                                                            <td>{res.prodct_id ? res.prodct_id:"Not Avaiable"  }</td>
                                                            <td>{res?.category_id?.name}</td>
                                                            <td>{res?.subcategory_id?.name}</td>
                                                            <td>{res?.brand_id?.name}</td>

                                                            <td className='product-image-table'>


                                                                {Array.isArray(res.images) || res.images.length ?
                                                                    <img src={henceforthApi.FILES.imageSmall(res.images[0])} alt="img" />

                                                                    : ""}
                                                            </td>
                                                            <td>{res.name ? res?.name?.slice(0,20):'Not Avaiable'}</td>
                                                            <td>&#36; {numberWithCommas(res.price)}</td>
                                                            <td>
                                                                <div className="btn-group gap-2">
                                                                    <Link className="btn btn-white btn-sm" to={`/product/${res._id}`}> <i className="fa fa-eye me-1"></i>View</Link>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </>
                                                )
                                            })}
                                        </tbody>
                                    </table>}
                                </div>
                                {/* pagination  */}
                                <div className='dashboad-pagination-box'>
                                    <PaginationLayout
                                        count={state?.data?.total_count as number}
                                        data={state?.data?.data}
                                        page={Number(match?.params.page)}
                                        limit={Number(limit)}
                                        loading={loading}
                                        onPageChange={(val: any) => onChangePagination(val)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <DownloadFileModal exportData={exportData} />
        </>
    )
}
export default ProductListing;