import profile_img1 from '../../assets/images/pages/laptop.jpg';
import { Link, useMatch, useNavigate } from 'react-router-dom'
import { GlobalContext, handleError } from '../../context/Provider';
import { Fragment, useContext, useEffect, useState } from 'react';
import henceforthApi from '../../utils/henceforthApi';
import { numberWithCommas } from '../../utils/validations';
import profile_placeholder from '../../assets/images/pages/profile_placeholder.png'
import moment from 'moment';
import { toast } from 'react-toastify';
import OrderStatus from '../../components/order/OrderStatus';
import henceofrthEnums from '../../utils/henceofrthEnums';
import OrderListing from '../../components/row_view/OrderRowListing';
import OrderRowListing from '../../components/row_view/OrderRowListing';
const OrderDetails = () => {

    const match = useMatch(`order/:id`)
    const { loading, setLoading } = useContext(GlobalContext)
    const navigate = useNavigate()
    const [state, setstate] = useState({
        price: 0,
        quantity: 0,
        total_price: 0,
        coupon_discount: 0,
        order_id: "",
        order_status: "",
        order_object_id: "",
        _id: "",
        product_id: {
            name: "",
            description: "",
            images: Array(""),
            _id: "",
            brand_id: {
                name: ""
            },
            ratings: [{}]
        },
        seller_id: {
            name: "",
            image: ""
        },
        user_id: {
            name: "",
            profile_pic: ""
        },
        address_id: {
            phone_no: 0,
            full_address: ""
        },
        tax_percentage: 0,
        other_order_items: []
    })
    const onChangeCancel = async () => {
        setLoading(true)
        try {
            const data = {
                _id: state.order_object_id,
                language: "ENGLISH"
            }
            let apiRes = await henceforthApi.Order.cancelOorder(data)
            navigate(`/orders/1`)
            toast.success(apiRes.data.message)
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Order.orderDetails(match?.params.id)
            setstate(apiRes.data)
        } catch (error) {
            handleError(error)
        }
    }

    useEffect(() => {
        initialise()
    }, [match?.params.id])
    console.log(state)
    return (
        <>
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">Order Detail</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Order Detail</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-detail'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12">
                                {/* Title  */}
                                <div className="common-card">
                                    <div className="common-card-title d-flex justify-content-between align-align-items-center">
                                        <h5>Order Detail</h5>
                                        {/* <div>
                                            <div className="btn-group gap-2">
                                                <button type="button" className="btn btn-white btn-sm bg-danger text-white border-danger" onClick={onChangeCancel} disabled={loading}> <i className="fa fa-trash me-1"></i>{loading ? <Spinner /> : "Order cancel"}</button>
                                            </div>
                                        </div> */}
                                    </div>
                                    {/* Profile  */}
                                    <div className="common-card-content">
                                        <div className="row">
                                            <div className="col-md-5">
                                                <div id="carouselExampleIndicators" className="carousel slide" data-bs-ride="true">
                                                    <div className="carousel-indicators">
                                                        {Array.isArray(state.product_id.images) && (state.product_id.images.length) ?
                                                            state.product_id.images.map((res: any, index: any) => {
                                                                return (
                                                                    <>
                                                                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" className={index == 0 ? "active" : ""} aria-current="true" aria-label={`Slide 1${index + 1}`}></button>
                                                                    </>
                                                                )
                                                            }) : ""}

                                                        {/* <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button> */}
                                                    </div>
                                                    <div className="carousel-inner product-images">
                                                        {Array.isArray(state.product_id.images) && (state.product_id.images.length)
                                                            ? state.product_id.images.map((res: any, index: any) => {
                                                                return <>
                                                                    <div className={`carousel-item ${index == 0 ? "active" : ""}`} key={index}>
                                                                        <img src={`${henceforthApi.FILES.imageMedium(res)}`} className="d-block w-100" alt="img" />
                                                                    </div>

                                                                </>
                                                            }) : <div className="carousel-item">
                                                                <img src={profile_img1} className="d-block w-100" alt="img" />
                                                            </div>}
                                                    </div>
                                                    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                                        <span className="visually-hidden">Previous</span>
                                                    </button>
                                                    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                                        <span className="visually-hidden">Next</span>
                                                    </button>
                                                </div>
                                            </div>
                                            {/* Product detail  */}
                                            <div className="col-md-7">
                                                <div className="product-detail-box">
                                                    <h2 className='fw-bolder'>{state.product_id?.name}</h2>
                                                    <div className='d-flex align-items-center gap-1'>
                                                        <h2 className='fw-lighter m-0'>&#36; {numberWithCommas(state.price)}</h2><small>Exclude Tax</small>
                                                    </div>
                                                    <div className="divider my-3"></div>
                                                    <div className='mb-3'>
                                                        <h4 className='fw-bolder'>Product description</h4>
                                                        <p>{state.product_id.description}</p>
                                                    </div>
                                                    <ul className='list-unstyled product-detail-list'>
                                                        <li className="d-flex mb-2"><b className='w-25'>Order ID:</b><span className='flex-grow-1 w-75'>{state.order_id ? state.order_id : "Not Avaiable"}</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Product ID:</b><span className='flex-grow-1 w-75'>{state.product_id._id ? state.product_id._id : "not Avaiable "}</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Product Name:</b><span className='flex-grow-1 w-75'>{state.product_id.name ? state.product_id.name : "Not Avaiable"}</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Price:</b><span className='flex-grow-1 w-75'>&#36; {state.price ? state.price : "Not Avaiable"}</span></li>
                                                        <li className="d-flex mb-2"><b className='w-25'>Brand</b><span className='flex-grow-1 w-75'>{state.product_id.brand_id.name ? state.product_id.brand_id.name : "Not Avaiable"}</span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* User seller order-status detail  */}
                        <div className="row">
                            {/* User Detail  */}
                            <div className="col-md-4 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>User Detail</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <div className="product-detail-box">
                                            <div className="profile-image">
                                                <img src={state.user_id.profile_pic ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state.user_id.profile_pic}` : profile_placeholder} alt="img" className='img-fluid' />
                                            </div>
                                            {/* Profile Detail  */}
                                            <div className="profile-image my-4">
                                                <h5 className='mb-3'>{state.user_id.name ? state.user_id.name : "Not Avaiable"}</h5>
                                                {/* <p className="d-flex align-items-center mb-2"><i className='fa fa-phone-square me-2 fs-5'></i>demo.kumar@mail.com</p> */}
                                                <p className="d-flex align-items-center mb-2"><i className='fa fa-envelope me-2 fs-5'></i>+91 {state?.address_id?.phone_no}</p>
                                                <p className="d-flex align-items-center"><i className='fa fa-map me-2 fs-5'></i>{state?.address_id?.full_address ? state?.address_id?.full_address : "Not Aviable"}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Seller Detail  */}
                            <div className="col-md-4 mb-3">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Seller Detail</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <div className="product-detail-box">
                                            <div className="profile-image">
                                                <img src={state.seller_id?.image ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state.seller_id?.image}` : profile_placeholder} alt="img" className='img-fluid' />
                                            </div>
                                            {/* Profile Detail  */}
                                            <div className="profile-image my-4">
                                                <h5 className='mb-3'>{state?.seller_id?.name}</h5>
                                                {/* <p className="d-flex align-items-center mb-2"><i className='fa fa-phone-square me-2 fs-5'></i>demo.kumar@mail.com</p>
                                                <p className="d-flex align-items-center mb-2"><i className='fa fa-envelope me-2 fs-5'></i>+91 123466790</p>*/}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/*Price Breakdown, Order and Delivery Status */}
                            <div className="col-md-4 mb-3">
                                <div className='h-100 d-flex flex-column'>
                                    <div className="common-card h-100">
                                        <div className="common-card-title d-flex justify-content-between align-items-center">
                                            <h5>Price Breakdown</h5>
                                            {(state.order_status === henceofrthEnums.OrderStatus.CONFIRMED || state.order_status === henceofrthEnums.OrderStatus.DELIVERED || state.order_status === henceofrthEnums.OrderStatus.PAID || state.order_status === henceofrthEnums.OrderStatus.PLACED || state.order_status === henceofrthEnums.OrderStatus.SHIPPED) &&
                                                <Fragment>
                                                    <button className="btn btn-white dropdown-toggle shadow-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i className="fa fa-download me-1"></i> Download
                                                    </button>
                                                    <ul className="dropdown-menu download-invoices-links py-0">
                                                        <li className='rounded-0 border-0'>
                                                            <Link to={`/invoice/${state.order_object_id}/${state._id}/SELLER`} className="btn text-start" target="_blank"> <i className="fa fa-user me-1"></i> Seller Invoice</Link>
                                                        </li>
                                                        <li className='rounded-0 border-0'>
                                                            <Link to={`/invoice/${state.order_object_id}/${state._id}/USER`} className="btn text-start" target="_blank"> <i className="fa fa-users me-1"></i> Customer Invoice</Link>
                                                        </li>
                                                    </ul>
                                                </Fragment>}

                                        </div>
                                        <ul className=' common-card-title list-unstyled product-detail-list'>
                                            <li className="d-flex mb-2"><b className='w-25'>Price</b><span className='flex-grow-1 w-75'>&#36;{state.price ? state.price : 0}</span></li>
                                            {/* <li className="d-flex mb-2"><b className='w-25'>Quantity</b><span className='flex-grow-1 w-75'>{state.quantity ? state.quantity : 0}</span></li> */}
                                            {/* <li className="d-flex mb-2"><b className='w-25'>Total Price</b><span className='flex-grow-1 w-75'>&#36;{state.total_price ? state.total_price : 0}</span></li> */}
                                            <li className="d-flex mb-2"><b className='w-25'>Seller</b><span className='flex-grow-1 w-75'>{state?.seller_id?.name ? state?.seller_id?.name : "Not Avaiable"}</span></li>
                                            {state.coupon_discount !== 0 &&
                                                <li className="d-flex mb-2"><b className='w-25'>Discount</b><span className='flex-grow-1 w-75 ms-1'>{state.coupon_discount}%</span></li>}
                                            <li className="d-flex mb-2"><b className='w-25'>tax:</b><span className='flex-grow-1 w-75'> {state.tax_percentage ? state.tax_percentage : "Not Avaiable"}{state.tax_percentage ? "%" : ''}</span></li>

                                        </ul>
                                    </div>
                                    {/* Order Status */}
                                    <div className="common-card h-100">
                                        <div className="common-card-title">
                                            <h5>Order Status</h5>
                                        </div>
                                        <div className="common-card-content">
                                            <div className="product-detail-box">
                                                <ul className='list-unstyled'>
                                                    <li><p className='mb-2 fw-bold'>Order Status------</p>
                                                        <OrderStatus {...state} />
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Delivery Status */}
                                    {/* <div className="common-card h-100">
                                        <div className="common-card-title">
                                            <h5>Delivery Status</h5>
                                        </div>
                                        <div className="common-card-content">
                                            <div className="product-detail-box">
                                                <ul className='list-unstyled'>
                                                    <li><p className='mb-2 fw-bold'>Delivery Status------</p>
                                                        <span className={`${state.order_status == henceofrthEnums.OrderStatus.PLACED ? 'text-bg-success px-2 py-half rounded-half text-white fs-10 fw-semibold mb-1 d-inline-block' : "" || state.order_status === henceofrthEnums.OrderStatus.CANCELLED ? "text-bg-danger px-2 py-half rounded-half text-white fs-10 fw-semibold mb-1 d-inline-block" : "" ||
                                                            state.order_status === henceofrthEnums.OrderStatus.PLACED ? "text-bg-info" : "" || state.order_status == henceofrthEnums.OrderStatus.PLACED ? "text-bg-warning px-2 py-half rounded-half text-white fs-10 fw-semibold mb-1 d-inline-block" : ""}`}>
                                                            {state.order_status}</span><br />
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                        {/* Ratings  */}
                        <div className="row">
                            {state.product_id.ratings.map((res: any) => {
                                return (
                                    <div className="col-md-12 mb-3">
                                        <div className="common-card h-100">
                                            <div className="common-card-title">
                                                <h5>Ratings</h5>
                                            </div>
                                            <div className="common-card-content">
                                                {/* 1  */}
                                                <div className='rating-box'>
                                                    <div className="rating-username product-image-table d-flex gap-2 mb-2">
                                                        <img src={res.user_detail?.profile_pic ? `${henceforthApi.API_FILE_ROOT_SMALL}${res.user_detail?.profile_pic}` : profile_placeholder} className="border rounded-circle" alt="img" />
                                                        <div>
                                                            <p className='fw-bold'>{res.user_detail?.name ? res.user_detail?.name : "Not Avaibale"}</p>
                                                            <ul className='list-unstyled d-flex gap-1 rating-icons m-0'>
                                                                <li><i className='fa fa-star text-warning'></i></li>
                                                                <li><i className='fa fa-star text-warning'></i></li>
                                                                <li><i className='fa fa-star text-warning'></i></li>
                                                                <li><i className='fa fa-star text-warning'></i></li>
                                                                <li><i className='fa fa-star text-warning'></i></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <p className='fw-bold'>{res.title}</p>
                                                        <p className='my-1'>{res.description}</p>
                                                        <p className='fw-bold'>{moment(Number(res.created_at)).format('ddd DD MMM, YYYY HH:MM:A')}</p>
                                                        <div className='review-img'>
                                                            <img src={profile_img1} alt="img" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='divider my-3'></div>
                                                {/* 2  */}

                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                        {Array.isArray(state?.other_order_items) && state?.other_order_items.length !== 0 &&
                            <div className="col-sm-12">
                                {/* Title  */}
                                <div className="common-card">
                                    <div className="common-card-title d-flex justify-content-between align-align-items-center">
                                        <h5>Other items in this order</h5>
                                    </div>
                                    <div className="common-card-content">

                                        <div className='data-list-table table-responsive mb-3'>
                                            <table className="table table-striped align-middle">
                                                <thead className=''>
                                                    <tr>
                                                        <th>Order ID</th>
                                                        <th>Customer Detail</th>
                                                        <th>Seller Detail</th>
                                                        <th>Product ID</th>
                                                        <th>Product Detail</th>
                                                        <th>Product Price</th>
                                                        <th>Order Status</th>
                                                        <th>Earning</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {state.other_order_items.map((res: any) => <OrderRowListing key={res._id} {...res} />)}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                    </div>
                </section>
            </div>
        </>
    )
}
export default OrderDetails;