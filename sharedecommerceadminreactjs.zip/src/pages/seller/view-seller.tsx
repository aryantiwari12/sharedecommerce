import React from 'react'
import profile_image from '../../assets/images/pages/profile-image.jpg' 
import laptop from '../../assets/images/pages/laptop.jpg'
import '../../assets/styles/pages.scss'
import { Link, useLocation, useMatch, useNavigate } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import { useContext, useEffect, useState } from 'react';
import henceforthApi from '../../utils/henceforthApi';
import { sellerdetails } from '../../context/interfaces';
import PaginationLayout from '../../components/PaginationLayout';
// import ProductListingDetails from './productListingDetail';
import { GlobalContext, handleError } from '../../context/Provider';
import { toast } from 'react-toastify'
import Spinner from '../../components/BootstrapCompo';
import Swal from 'sweetalert2'

const ViewSeller = () => {
    const { authState, authDispatch } = useContext(GlobalContext);
    const match: any = useMatch("/view-seller/:id")
    let limit = 10
    const navigate = useNavigate()
    const location = useLocation()
    const [loading, setloading] = useState(false)
    const [searchdata, setsearchdata] = useState()
    const [state, setState] = useState<sellerdetails>()
   
    const onChnageDelete = async () => {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
          }).then(async (result:any) => { 
            if (result.isConfirmed) {
                try {
                    setloading(true)
                    let apires = await henceforthApi.Seller.sellerdelete(match?.params.id)
                    toast.success(apires.data.message)
                    window.history.back()
                } catch (error) {
                    handleError(error)
                } finally {
                    setloading(false)
                }
            }
          })
        // try {
        //     let apires = await henceforthApi.Seller.sellerdelete(match?.params.id)
        //     toast.success(apires.data.message)
        //     window.history.back()
        // } catch (error) {
        //     handleError(error)
        // } finally {
        //     setloading(false)
        // }
    }
    const sellerdetails = async () => {
        try {
            let Apies = await henceforthApi.Seller.details(match?.params.id)
            setState(Apies)
        } catch (error) {

        } finally {

        }
    }

    const onChangeActiveDeactive = async () => {
        const data = {
            type: "ACTIVATE/DEACTIVATE",
            _id: state?.data._id,
            account_status: state?.data.account_status == "ACTIVATED" ? `DEACTIVATED` : `ACTIVATED`,
        }
        try {
            let apires = await henceforthApi.Seller.manageSeller(data)
            sellerdetails()
        } catch (error) {
            handleError(error)
        } finally {

        }
    }
    const onChangeBlockUnblock = async () => {

        const data = {
            type: "BLOCK/DELETE",
            _id: state?.data._id,
            is_blocked: state?.data.is_blocked == true ? false : true,
            is_deleted: state?.data.is_deleted == true ? false : true,
            language: "ENGLISH"
        }
        try {
            let apires = await henceforthApi.Seller.manageSeller(data)
            sellerdetails()
        } catch (error) {
            console.log(error)
        } finally {

        }
    }
    useEffect(() => {
        sellerdetails()
    }, [])

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className="fw-semibold">View Seller</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">View Seller</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='change-password'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-3">
                                {/* Profile Card  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>View Seller</h5>
                                    </div>
                                    {/* Profile  */}
                                    <div className="common-card-content">
                                        {/* Profile image  */}
                                        <div className="profile-image">
                                            <img src={`${henceforthApi.API_FILE_ROOT_ORIGINAL}${state?.data?.image}` ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${state?.data?.image}` : ""} alt="img" className='img-fluid' />
                                        </div>
                                        {/* Profile Detail  */}
                                        <div className="profile-image my-4">
                                            <h5 className='mb-3'>{state?.data?.name}</h5>
                                            <p className="d-flex align-items-center mb-1"><i className='fa fa-envelope me-2 fs-5'></i>{state?.data?.email}</p>
                                            <p className="d-flex align-items-center"><i className='fa fa-phone-square me-2 fs-5'></i>+91 {state?.data?.phone_number}</p>
                                        </div>
                                        {/* button  */}
                                        <div className="profile-button">
                                            <ul className='list-unstyled d-flex gap-2  flex-wrap'>
                                                <li className='w-100'>
                                                    <a href={`https://sharedecommerce.henceforthsolutions.com:8090/login-with-user/${state?.data?._id}/${authState.access_token}`} target="_blank">
                                                        <button type='button' className='btn btn-theme w-100'><i className='fa fa-sign-in me-1'></i> Login as seller</button>
                                                    </a>
                                                </li>
                                                <li className='w-100'><button type='button' className='btn btn-white w-100 bg-danger text-white' onClick={onChnageDelete} disabled={loading}><i className='fa fa-trash me-1'></i>{loading ? <Spinner /> : "Delete"}</button></li>
                                                <li className='w-100'>
                                                    <button type='button' className='btn btn-white bg-black text-white w-100' onClick={onChangeActiveDeactive}>
                                                        {state?.data.account_status == "ACTIVATED" ? <span> <i className='fa fa-toggle-on me-1'></i>Activate</span> : <span><i className='fa fa-toggle-on me-1'></i>Deactivate</span>}</button></li>
                                                       
                                                <li className='w-100'>
                                                    <button type='button' className='btn btn-white bg-dark text-white w-100' onClick={onChangeBlockUnblock}>
                                                       {state?.data.is_blocked==false ? <span> <i className='fa fa-ban me-1'></i>Block</span>:<span><i className='fa fa-ban me-1'></i>Unblock</span> }
                                                        </button></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/************************************** Product Order details  *************************************/}
                            <div className="col-xxl-9">
                                {/************************************** Product list details  *************************************/}
                                <div className='product-detail-box'>
                                    {/* <ProductListingDetails id={(match?.params.id)} /> */}
                                </div>

                                {/************************************** order detail  *************************************/}
                                {/* <div className='order-detail-box'>
                                    <div className='common-card mb-4 border-0 card-spacing'>
                                        <div className="row d-flex justify-content-between">
                                            serach and filter 
                                            <div className="col-md-7">
                                                <div className="row">
                                                    <div className="col-8">
                                                        <div className='form-fields-box'>
                                                            <label className='mb-1 form-label fw-semibold'>Search</label>
                                                            <div className='position-relative'>
                                                                <input type="search" className="form-control rounded-0 ps-4 " placeholder="Search by Order id, Customer name, Product id, Product name..." />
                                                                <span className='search-icon'><i className='fa fa-search'></i></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    filter
                                                    <div className="col-4">
                                                        <div className='form-select-box'>
                                                            <label className='mb-1 form-label fw-semibold'>Filter</label>
                                                            <select className="form-select shadow-none" aria-label="Default select example">
                                                                <option selected disabled>Filter By</option>
                                                                <option value="1">Order Status</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            filter by date 
                                            <div className="col-md-3">
                                                <div className='d-flex gap-2'>
                                                    <div className='form-fields-box'>
                                                        <label className='mb-1 form-label fw-semibold'>Start date:</label>
                                                        <input type="date" className='form-control rounded-0' placeholder='dd/mm/yy' />
                                                    </div>
                                                    <div className='form-fields-box'>
                                                        <label className='mb-1 form-label fw-semibold'>End date:</label>
                                                        <input type="date" className='form-control rounded-0' placeholder='dd/mm/yy' />
                                                    </div>
                                                </div>
                                            </div>
                                            export 
                                            <div className="col-md-1 ms-5">
                                                <div className='d-flex gap-3 justify-content-end'>
                                                    <div className='download-export-box'>
                                                        <label className='mb-1 form-label fw-semibold'>Export File</label>
                                                        <div className="export-button">
                                                            <button className="btn btn-white" type="button" data-bs-toggle="modal" data-bs-target="#fileDownloadModal"> <i className='fa fa-cloud-download me-2'></i>.csv</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="common-card">
                                        <div className="common-card-title">
                                            <h5>Orders (Sales) Detail</h5>
                                        </div>
                                        <div className="common-card-content">
                                            product list table
                                            <div className='data-list-table table-responsive mb-3'>
                                                <table className="table table-striped align-middle">
                                                    <thead className=''>
                                                        <tr>
                                                            <th>Order Id</th>
                                                            <th>Customer Detail</th>
                                                            <th>Product Detail</th>
                                                            <th>Order Status</th>
                                                            <th>Order Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1001</td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center align-items-center gap-2'>
                                                                    <img src={profile_image} alt="img" className='rounded-circle' />
                                                                    <span>Rajesh</span>
                                                                </div>
                                                            </td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center gap-2'>
                                                                    <img src={laptop} alt="img" />
                                                                    <div className='product-detail-table'>
                                                                        <p><b>Id:</b>10250</p>
                                                                        <p>Laptop</p>
                                                                        <p><b>&#8377;</b> 40000</p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <span className='text-bg-danger px-2 py-half rounded-half text-white fs-10 fw-semibold'>Failed</span>
                                                                <p>10 Oct 2022</p>
                                                            </td>
                                                            <td>6 Oct 2022</td>
                                                        </tr>
                                                        <tr>
                                                            <td>1001</td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center align-items-center gap-2'>
                                                                    <img src={profile_image} alt="img" className='rounded-circle' />
                                                                    <span>Rajesh</span>
                                                                </div>
                                                            </td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center gap-2'>
                                                                    <img src={laptop} alt="img" />
                                                                    <div className='product-detail-table'>
                                                                        <p>Laptop</p>
                                                                        <p><b>&#8377;</b> 40000</p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td className='status-badge'>
                                                                <span className='text-bg-success px-2 py-half rounded-half text-white fs-10 fw-semibold'>Delivered</span>
                                                                <p>10 Oct 2022</p>
                                                            </td>
                                                            <td>6 Oct 2022</td>
                                                        </tr>
                                                        <tr>
                                                            <td>1001</td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center align-items-center gap-2'>
                                                                    <img src={profile_image} alt="img" className='rounded-circle' />
                                                                    <span>Rajesh</span>
                                                                </div>
                                                            </td>
                                                            <td className='product-image-table'>
                                                                <div className='d-flex justify-content-center gap-2'>
                                                                    <img src={laptop} alt="img" />
                                                                    <div className='product-detail-table'>
                                                                        <p>Laptop</p>
                                                                        <p><b>&#8377;</b> 40000</p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td className='status-badge'>
                                                                <span className='text-bg-warning px-2 py-half rounded-half text-white fs-10 fw-semibold'>Pending</span>
                                                                <p>10 Oct 2022</p>
                                                            </td>
                                                            <td>6 Oct 2022</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            pagination 
                                            <div className='dashboad-pagination-box'>
                                                <nav aria-label="Page navigation example">
                                                    <ul className="pagination justify-content-end mb-0">
                                                        <li className="page-item">
                                                            <Link className="page-link btn btn-sm btn-white" to="" aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </Link>
                                                        </li>
                                                        <li className="page-item"><Link className="page-link btn btn-sm btn-white rounded-0" to="">1</Link></li>
                                                        <li className="page-item"><Link className="page-link btn btn-sm btn-white rounded-0 active-btn" to="">2</Link></li>
                                                        <li className="page-item"><Link className="page-link btn btn-sm btn-white rounded-0" to="">3</Link></li>
                                                        <li className="page-item">
                                                            <Link className="page-link btn btn-sm btn-white" to="" aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                                
                            </div>
                        </div>
                    </div>
                </section>
            </div >

            
        </>
    )
}
export default ViewSeller;