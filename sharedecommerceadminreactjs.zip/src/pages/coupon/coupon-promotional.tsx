import { useContext, useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { toast } from "react-toastify"
import { listApiResponse } from "../../context/interfaces"
import { GlobalContext, handleError } from "../../context/Provider"
import henceforthApi from "../../utils/henceforthApi"
import Swal from 'sweetalert2'
import { loadavg } from "os"
import Spinner from "../../components/BootstrapCompo"
import moment from "moment"


const CouponPromotional = () => {

    const { loading, setLoading } = useContext(GlobalContext);
    const [state, setState] = useState({
        loading: false,
        limit: 10
    } as listApiResponse)
    const [show, setShow] = useState({
        name: ""
    } as any)
    const [couponId, setCouponId] = useState('')
    const initialiseData = async () => {
        try {
            setState((state) => {
                return {
                    ...state,
                    loading: true
                }
            })
            const apiRes = await henceforthApi.Coupons.promotionaget()
            setState((state) => {
                return { ...state, ...apiRes, loading: false }
            })
        } catch (error) {
            handleError(error)
            setState((state) => {
                return {
                    ...state,
                    loading: false
                }
            })
        }
    }
    const intialise = async () => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Coupons.showCoupon()
            setShow(apiRes.data)
            setLoading(false)
        } catch (error) {

        }
    }
    const onChangeSubmit = async (e: any) => {
        e.preventDefault()
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, update it!",
        }).then(async (result: any) => {
            if (result.isConfirmed) {
                try {
                    let apiRes = await henceforthApi.Coupons.homeCoupon(couponId, '', true)
                    toast.success(apiRes.message)
                    intialise()

                    // window.history.back()
                } catch (error) {
                    handleError(error)
                }
            }
        })
     }

    const homedisable = async () => {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, update it!",
        }).then(async (result: any) => {
            if (result.isConfirmed) {
                try {
                    let apiRes = await henceforthApi.Coupons.homeCoupon(show._id, '', false)
                    // setShow({
                    //     ...show,
                    //     name:''
                    // })
                    setCouponId('hide')
                    toast.success(apiRes.message)
                    intialise()
                    initialiseData()
                    // window.history.back()
                } catch {

                }
            }
        })

    }

    useEffect(() => {
        initialiseData()
        intialise()
    }, [])
    // console.log( state?.data?.data.find((res=>res.name===show.name)).name);

    console.log(show)

    return (
        <>
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <div className='d-flex justify-content-between align-items-center'>
                                <div>
                                    {/* title  */}
                                    <h2 className='fw-semibold'>promotional</h2>
                                    {/* breadcrum  */}
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb m-0">
                                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                            <li className="breadcrumb-item active fw-bold">promotional</li>
                                        </ol>
                                    </nav>
                                </div>
                                 
                                
                                    <div className='enable-diable-button'>
                                        {loading ? <Spinner/>: 
                                        <button className={`btn btn-white btn-sm border-danger text-white ms-2 bg-danger`} type="button" value={show._id} onClick={homedisable} disabled={!show.name} >
                                            <span> <i className="fa fa-ban me-1"> Disable</i></span>
                                        </button>}

                                    </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {loading ? <div className='vh-100 d-flex justify-content-center py-5'>
                <Spinner />
            </div> :
                <div className='page-spacing'>

                    <section className='product-detail'>
                        <div className="container-fluid">

                            <div className="row">
                                <div className="col-sm-12 ">
                                    {/* Title  */}
                                    <div className="common-card">
                                        <div className="common-card-title">
                                            <h5>Home Promotional Coupon</h5>
                                        </div>
                                        <div className="common-card-content">
                                            <form onSubmit={onChangeSubmit}>
                                                {/* sub Categories  */}
                                                <div className="form-select-box mb-3 is-invalid">
                                                    <label className="mb-1 fw-bold">Home Promotional Coupon</label>
                                                    <select className="form-select" aria-label="Default select example" value={!couponId ? state?.data?.data?.find((res => res?.name === show?.name))?._id : couponId} onChange={(e) => setCouponId(e.target.value ? e.target.value : 'disable')}
                                                    >

                                                        <option value="" >
                                                            Select{/* {show.for_homepage==true? `${show?.name}`:''} */}
                                                        </option>

                                                        {state?.data?.data.map((res: any) => {
                                                            return <>

                                                                <option value={res._id}>{res.name}</option>
                                                            </>
                                                        }


                                                        )}

                                                    </select>

                                                </div>


                                                {/* Submit button  */}


                                                <div className="button-box">

                                                    <button className='btn btn-theme w-100' disabled={couponId === "disable"}>Add  promotional</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                  
                            </div>
                        </div>
                        {show.for_homepage==true ?  
                        <div className="container-fluid">
                             <div className="row">
                                <div className="col-sm-12 ">
                                    {/* Title  */}
                                    <div className="common-card">
                                        <div className="common-card-title">
                                            <h5>Home Promotional Coupon</h5>
                                        </div>
                                        <div className="common-card-content">
                                            <form >
                                                {/* sub Categories  */}
                                                <div className="form-select-box mb-3 is-invalid">
                                                      <label className="mb-1 fw-bold"> Name:  </label>
                                                      <span>{show.name ? show.name :"Not Avaiable" }</span><br/>
                                                      <label className="mb-1 fw-bold">Coupon Code:</label>
                                                      <span>{show.code ? show.code :"Not Avaiable" }</span><br/>
                                                      <label className="mb-1 fw-bold">created_at:</label>
                                                      <span>{moment(Number(show.created_at)).format("MMM Do YY") }</span><br/>
                                                      <label className="mb-1 fw-bold">Max-Discount:</label>
                                                      <span>{show.max_discount? show.max_discount:0}</span><br/>
                                                      <label className="mb-1 fw-bold">Percentage:</label>
                                                      <span>{show.percentage? show.percentage:0 }</span><br/>
                                                      <label className="mb-1 fw-bold">Price:</label>
                                                      <span>{show.price? show.price:0 }</span><br/>
                                                      <label className="mb-1 fw-bold">Start-date:</label>
                                                      <span>{show.start_date? show.start_date:"Not Avaiable" }</span><br/>
                                                      <label className="mb-1 fw-bold">End-date:</label>
                                                      <span>{show.end_date? show.end_date:"Not Avaiable" }</span><br/>
                                                  </div>
                                             </form>
                                        </div>
                                    </div>
                                </div>
                  
                            </div>
                        </div>:''}
                    </section>
                </div>}
        </>
    )
}
export default CouponPromotional