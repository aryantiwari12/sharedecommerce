import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import { Link } from 'react-router-dom'
import profile_image from '../../assets/images/pages/profile-image.jpg'
import { useEffect, useState } from 'react'
import henceforthApi from '../../utils/henceforthApi'
import { handleError } from '../../context/Provider'
import { content } from '../../context/interfaces'
import { match } from 'assert'
import profile_pic from "../../assets/images/profile_placeholder.png"
import BreadCrumb from '../../components/common/BreadCrumb'

interface contentResponse {
    type: string,
    description: string
    image_url: string
    _id: string
}
let breadCrumbPath = [
    { name: 'Home', url: `/`, active: '' },
    { name: 'Content', url: ``, active: 'not-allowed' }
]

const Content = () => {

    const [state, setState] = useState({
        data: []
    } as content)

    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Content.AboutusList()
            setState(apiRes)
        } catch (error) {
            handleError(error)
        } finally {

        }
    }
    useEffect(() => {
        initialise()
    }, [])



    return (
        <>
            {/* breadcrum  */}

            <BreadCrumb pathNameDeclare={breadCrumbPath} />

            {/* page  */}
            <div className='page-spacing'>
                <section className='product-listing'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <div className='d-flex align-items-center justify-content-between'>
                                            <h5>Content</h5>
                                        </div>
                                    </div>

                                    <div className="common-card-content">
                                        <div className='data-list-table table-responsive mb-3'>
                                            <table className="table table-striped align-middle">
                                                <thead className=''>
                                                    <tr>
                                                        <th>Sr.No.</th>
                                                        <th>Title</th>
                                                        <th>Image</th>
                                                        <th>Content</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {Array.isArray(state?.data) && (state?.data.length) ? state?.data.map((res: contentResponse, index: any) => {
                                                        return (
                                                            <>
                                                                <tr>
                                                                    <td>{index + 1}</td>
                                                                    <td>{res.type}</td>
                                                                    <td className='product-image-table'>
                                                                        <img src={res?.image_url ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res?.image_url}` : profile_pic} alt="img" className='rounded-circle' />
                                                                    </td>
                                                                    <td>
                                                                        <div className='page-content-box'>
                                                                            <h3></h3>
                                                                            <p className='panel-text-truncate' dangerouslySetInnerHTML={{ __html: res.description }}></p>
                                                                        </div>
                                                                    </td>
                                                                    <td><div className="btn-group gap-2">
                                                                        <Link to={`/view-content/${res?._id}`} className="btn btn-white btn-sm"> <i className='fa fa-eye me-1'></i>View</Link>
                                                                        <Link to={`/edit-content/${res?.type}`} className="btn btn-white btn-sm" type="button"> <i className='fa fa-sign-in me-1'></i>Edit</Link>
                                                                    </div>
                                                                    </td>
                                                                </tr>

                                                            </>
                                                        )
                                                    }) : <tr><td className='text-center' colSpan={5}>No Data found</td></tr>}
                                                </tbody>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </>
    )
}
export default Content;