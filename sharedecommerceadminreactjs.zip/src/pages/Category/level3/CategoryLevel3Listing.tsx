import { Link, useLocation, useMatch, useNavigate } from 'react-router-dom'
import DownloadFileModal from '../../../components/common/download-file-modal'
import { useContext, useEffect, useState } from 'react'
import henceforthApi from '../../../utils/henceforthApi'
import Swal from 'sweetalert2'
import PaginationLayout from '../../../components/PaginationLayout'
import { GlobalContext, handleError } from '../../../context/Provider'
import { listApiResponse } from '../../../context/interfaces'
import moment from 'moment'
import { toast } from 'react-toastify'

const CategoryLevel3Listing = () => {
    const limit = 10;
    const navigate = useNavigate();
    const location = useLocation();
    const match = useMatch("/category/level-3/:page")
    const urlSearchParams = new URLSearchParams(location.search);

    const { authState, authDispatch } = useContext(GlobalContext);
    const [state, setState] = useState({} as listApiResponse)
    const [loading, setLoading] = useState(false)
    henceforthApi.setToken(authState.access_token);

    const initialise = async (search: string, pagination: number) => {
        try {
            setLoading(true)
            const apiRes = await henceforthApi.Category.listSubSubCategory(search, pagination - 1, 10)
            setState(apiRes)
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }
    const exportData = async (startDate: number, endDate: number) => {


    }
    const onChangePagination = (page: number) => {
        navigate({ pathname: `/category/level-3/${page}`, search: urlSearchParams.toString() })

    }
    const onSearch = (search: string) => {
        let urlSearchParams = new URLSearchParams();
        if (search) {
            urlSearchParams.set("search", search)
        }
        navigate({ search: urlSearchParams.toString() })
    }
    const onChangeDelete = async (_id: string, is_deleted: boolean) => {

        const data = {
            _id: _id,
            is_deleted,
            language: "ENGLISH"
        }
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: `Yes, ${is_deleted ? 'delete' : 'enable'} it!`,
        }).then(async (result: any) => {
            if (result.isConfirmed) {
                try {

                    let apiRes = await henceforthApi.Category.subSubCategoryDelete(data)
                    toast.success(apiRes.message)
                    initialise(urlSearchParams.get("search") as string, Number(match?.params.page))
                } catch (error) {
                    handleError(error)
                }
            }
        })

    }

    useEffect(() => {
        initialise(urlSearchParams.get("search") as string, Number(match?.params.page))
    }, [urlSearchParams.get("search"), match?.params.page])

    return (
        <>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title  */}
                            <h2 className='fw-semibold'>Category List</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Sub-Sub-Category list</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-listing'>
                    <div className="container-fluid">
                        {/* search-filter-export */}
                        <div className='common-card mb-4 border-0 card-spacing'>
                            <div className="row justify-content-between">
                                {/* serach and filter  */}
                                <div className="col-md-7">
                                    <div className="row">
                                        <div className="col-7">
                                            <div className='form-fields-box'>
                                                <label className='mb-1 form-label fw-semibold'>Search</label>
                                                <div className='position-relative'>
                                                    <input type="search" className="form-control rounded-0 ps-4 " name='search' placeholder="Search by Name"
                                                        value={urlSearchParams.get("search") as string} onChange={(e) => onSearch(e.target.value)} />
                                                    <span className='search-icon'><i className='fa fa-search'></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* export  */}
                                <div className="col-md-2">
                                    <div className='d-flex gap-3 justify-content-end'>
                                        <div className='download-export-box'>
                                            <label className='mb-1 form-label fw-semibold'>Add</label>
                                            <div className="export-button">
                                                <Link to="/category/level-3/add" className="btn btn-white"> <i className='fa fa-plus me-2'></i>Add</Link>
                                            </div>
                                        </div>
                                        {/* export  */}
                                        <div className='download-export-box'>
                                            <label className='mb-1 form-label fw-semibold'>Export File</label>
                                            <div className="export-button">
                                                <button className="btn btn-white" type="button" data-bs-toggle="modal" data-bs-target="#fileDownloadModal"> <i className='fa fa-cloud-download me-2'></i>.csv</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* table  */}
                        <div className="row">
                            <div className="col-md-12">
                                <div className="common-card">
                                    <div className="common-card-content">
                                        {/* table */}
                                        <div className='data-list-table table-responsive mb-3'>
                                            <table className="table table-striped align-middle">
                                                <thead className=''>
                                                    <tr>
                                                        <th>Sr.no</th>
                                                        <th>Name</th>
                                                        <th>Created At</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {state?.data?.data?.map((res, index) =>
                                                        <tr key={res._id}>
                                                            <td>{Number(match?.params.page) == 0
                                                                ? index + 1
                                                                : (Number(match?.params.page) - 1) * limit + (index + 1)}</td>
                                                            <td>{res.name}</td>
                                                            <td>{moment(Number(res.created_at)).format("DD/MM/YYYY")}</td>
                                                            <td><div className="btn-group gap-2">

                                                                <Link className="btn btn-white btn-sm" to={`/category/level-3/edit/${res.name}/${res?._id}`}> <i className="fa fa-edit me-1"></i>Edit</Link>

                                                                {res.is_deleted ?
                                                                    <button className="btn btn-secondary btn-sm" onClick={() => onChangeDelete(res._id, false)}><i className='fa fa-exchange me-1'></i>Enable</button> :
                                                                    <button className="btn btn-danger btn-sm" onClick={() => onChangeDelete(res._id, true)}><i className='fa fa-trash me-1'></i>Delete</button>
                                                                }
                                                            </div></td>
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </table>
                                        </div>
                                        {/* pagination  */}
                                        <div className='dashboad-pagination-box'>
                                            <PaginationLayout
                                                count={state?.data?.total_count}
                                                data={state?.data?.data}
                                                page={Number(match?.params.page)}
                                                limit={Number(limit)}
                                                loading={loading}
                                                onPageChange={(val: number) => onChangePagination(val)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <DownloadFileModal exportData={exportData} />
        </>
    )
}
export default CategoryLevel3Listing;