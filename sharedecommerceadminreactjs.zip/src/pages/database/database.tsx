import React, { Fragment } from 'react';
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify';
import { GlobalContext, handleError } from '../../context/Provider';
import henceforthApi from '../../utils/henceforthApi';
const Database = () => {
    const { authState } = React.useContext(GlobalContext)
    const [loading, setLoading] = React.useState(false)

    henceforthApi.setToken(authState.access_token)

    const downloadDb = async () => {
        try {
            setLoading(true)
            const apiRes = await henceforthApi.Common.backupDb({ language: "ENGLISH" })
            toast.success(apiRes.message)
        } catch (error) {
            handleError(error)
        } finally {
            setLoading(false)
        }
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <section className="breadcrum-box">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            {/* title */}
                            <h2 className='fw-semibold'>Database Backup</h2>
                            {/* breadcrum  */}
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb m-0">
                                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                    <li className="breadcrumb-item active fw-bold">Database Backup</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </section>
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-listing'>
                    <div className="container-fluid">
                        {/* Order list table  */}
                        <div className="row">
                            <div className="col-md-12">
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Database Backup</h5>
                                    </div>
                                    <div className="common-card-content text-center">
                                        <p className='mb-2'>If you click on Download, Database will be downloaded.</p>
                                        <p>Db MySql file: <button className='btn btn-success' onClick={downloadDb} disabled={loading}>Download</button></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}
export default Database;