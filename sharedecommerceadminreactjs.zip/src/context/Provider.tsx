import React, { createContext, ReactNode, SetStateAction, useEffect, useReducer, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import auth from './reducers/auth';
import logoutSuccess from "./actions/auth/logoutSuccess";
import henceforthApi from '../utils/henceforthApi';
// import authInitialStaticData from "./initialStates/authInitialStaticData";
import { DASHBOARD, USERS, CONTACT, CONTENT, HOME_MANAGEMENT, DB_BACKUP, FAQ, SELLER, PRODUCTS, ORDER, COUPONS, CATEGORY, BRAND, NOTIFICATION, STAFF_MEMBER } from '../context/actionTypes'
interface CommonContextType {
    loading: boolean;
    setLoading: React.Dispatch<SetStateAction<boolean>>;

    authState: { access_token: String, name: String, email: String, phone_number: number, image: String, super_admin: string, roles: Array<string> };
    authDispatch: any;
    logOutNow: any;
    onChangeBack: any;
    handleSearch: any,
    onFilterPriceHandler: any
    numericValue: any
    staffMembers: any,
    brand: Array<string>,
    category: Array<string>,
    categoryId: any,
    setCategoryId: any,
    subCategory: Array<string>,
    subCategoryId: any,
    setSubCategoryId: any,
    subSubCategory: Array<string>,
    subSubCategoryId: any
    setSubSubcategoryId: any,
    brandID: any,
    setbrandID: any,
    nestedData: Array<string>
}


export const GlobalContext = createContext({} as CommonContextType);
export const handleError = (error: any) => toast.error((typeof error?.response?.body?.error_description === "string") ? error?.response?.body?.error_description : JSON.stringify(error?.response?.body?.error_description))


export const downloadFile = (file_path: String) => {
    var a: any = document.createElement('a') as HTMLElement;
    a.href = file_path;
    a.target = "_blank";
    a.download = file_path.substr(file_path.lastIndexOf('/') + 1);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}
// export const onChangeBack = () => {
//     window.history.back()
// }
export const MetamaskResource = {
    icon: 'https://raw.githubusercontent.com/MetaMask/brand-resources/master/SVG/metamask-fox.svg',
    name: 'Metamask',
    title: 'Connect with metamask'
}
export const WalletConnectResource = {
    icon: 'https://raw.githubusercontent.com/WalletConnect/walletconnect-assets/master/Logo/Blue%20(Default)/Logo.svg',
    name: 'WalletConnect',
    title: 'Connect with walletConnect'
}
type GlobleContextProviderProps = {
    children: ReactNode;
}

function GlobalProvider(props: GlobleContextProviderProps) {
    const location = useLocation()
    const newParam = new URLSearchParams(location.search);
    let navigate = useNavigate();
    const [loading, setLoading] = useState(false)
    const [brand, setbrand] = useState([])
    const [brandID, setbrandID] = useState("")

    const [category, setCategory] = useState([])
    const [categoryId, setCategoryId] = useState("")

    const [subCategory, setSubCategory] = useState([])
    const [subCategoryId, setSubCategoryId] = useState("")

    const [subSubCategory, setSubSubCategory] = useState([])
    const [subSubCategoryId, setSubSubcategoryId] = useState("")

    const [nestedData, setNestedData] = useState([])
    const [authState, authDispatch] = useReducer(auth, {}, () => {
        const localAuthState = localStorage.getItem("authState");
        return localAuthState ? JSON.parse(localAuthState) : {}
    })

    const scrollToTop = () => {
        if (window) {
            window.scrollTo(0, 0);
        }
    }
    const logOutNow = () => {
        logoutSuccess({})(authDispatch);
        // logoutSuccess(authInitialStaticData)(staticDataDispatch);
        navigate("/", { replace: true });
    };
    const onChangeBack = () => {
        window.history.back()
    }
    const numericValue = (e: any) => {

        if (!/[0-9]/.test(e)) {
            e.preventDefault();
        }

    }
    const handleSearch = (name: string, value: string) => {
        if (value) {
            if (name === "product_id") newParam.delete("search")
            if (name === "search") newParam.delete("product_id")
            if (name === "order_status") newParam.delete("payment_status")
            if (name === "payment_status") newParam.delete("order_status")
            if (name === 'start_date') newParam.delete('end_date')
            if (name === 'stock') newParam.delete('order_status'); newParam.delete('payment_status')
            if (name === 'order_status') newParam.delete('stock'); newParam.delete('payment_status')
            if (name === 'payment_status') newParam.delete('order_status'); newParam.delete('stock')
            if (name === "product_id") {
                newParam.delete("search")
            }
            if (name === "search") {
                newParam.delete("product_id")
            }
            // if (name === "order_status") {
            //     newParam.delete("payment_status")
            // }
            // if (name === "payment_status") {
            //     newParam.delete("order_status")
            // }
            // if (name === 'start_date') {
            //     newParam.delete('end_date')
            // }
            newParam.set(name, value)
        } else {
            if (newParam.has(name)) {
                newParam.delete(name)
            }
            if (name === 'start_date') {
                newParam.delete('end_date')
            }
        }
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: "/orders/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: "/products/1",
                search: newParam.toString()
            })
        }
    }
    const onChangePagination = (page: number) => {
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: `/orders/${page}`,
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/coupons')) {
            navigate({
                pathname: `/coupons/${page}`,
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: `/products/${page}`,
                search: newParam.toString()
            })
        }
    }
    const onFilterPriceHandler = (min_price: string, max_price: string) => {

        if (min_price && max_price) {
            newParam.set("min_price", min_price)
            newParam.set("max_price", max_price)
        } else {
            if (newParam.has("min_price") && newParam.has("max_price")) {
                newParam.delete("min_price")
                newParam.delete("max_price")
            }
        }
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: "/orders/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1?order_status=CANCELLED",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: "/products/1",
                search: newParam.toString()
            })
        }
    }

    const initialiseBrand = async () => {
        try {
            let apiRes = await henceforthApi.HomeManagemnt.Brands()
            setbrand(apiRes?.data.data)
        } catch (error) {

        }
    }
    const initialiseCategoryLevel1 = async () => {
        try {
            let apiRes = await henceforthApi.Category.listCategory()
            setCategory(apiRes?.data.data)
        } catch (error) {

        }
    }
    const initialiseCategoryLevel12 = async () => {
        try {
            let apiRes = await henceforthApi.Category.filterSubCategory(categoryId)
            setSubCategory(apiRes?.data.data)
        } catch (error) {

        }
    }
    const initialiseCategoryLevel3 = async () => {
        try {
            const apiRes = await henceforthApi.Category.filterSubSubCategory(subCategoryId)
            setSubSubCategory(apiRes?.data.data)
        } catch (error) {
            handleError(error)
        }
    }
    const staffMembers = [
        STAFF_MEMBER, DASHBOARD, USERS, CONTACT, CONTENT, HOME_MANAGEMENT, DB_BACKUP, FAQ, SELLER, PRODUCTS, ORDER, COUPONS, CATEGORY, BRAND, NOTIFICATION

    ]
    const nested = async () => {
        try {
            let apiRes = await henceforthApi.Common.nested()
            setNestedData(apiRes.data.data)
        } catch (error) {
        }
    }
    const BrandData = async () => {
        try {
            let apires = await henceforthApi.HomeManagemnt.Brands()
            setbrand(apires?.data.data)
        } catch {
            console.log("error")
        }
    }

    useEffect(scrollToTop, [location.pathname])
    useEffect(() => {
        localStorage.setItem("authState", JSON.stringify(authState))
    }, [authState]);
    useEffect(() => {
        initialiseBrand()
    }, [])
    useEffect(() => {
        initialiseCategoryLevel1()
    }, [])
    useEffect(() => {
        if (categoryId) {
            initialiseCategoryLevel12()
        }
    }, [categoryId])
    useEffect(() => {
        if (subCategoryId) {
            initialiseCategoryLevel3()
        }
    }, [subCategoryId])
    useEffect(() => {
        nested()
    }, [])

    return (
        <GlobalContext.Provider
            value={{
                loading, setLoading,
                brand, category, authState,
                authDispatch, logOutNow, onChangeBack, numericValue,
                staffMembers, categoryId,
                setCategoryId, subCategory, subCategoryId, setSubCategoryId,
                subSubCategory, subSubCategoryId, setSubSubcategoryId,
                brandID, setbrandID, nestedData, handleSearch, onFilterPriceHandler
            }}>
            {props.children}
            <ToastContainer autoClose={2000} />
        </GlobalContext.Provider>
    )
}

export default GlobalProvider
